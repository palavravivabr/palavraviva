/* Palavra Viva – Aprendendo as Escrituras: app (interface + leitura + estudo). Offline primeiro. Sem dependências externas.
   Regras do plano: conteúdo só entra se o hash conferir; aba sem conteúdo não aparece; o último conteúdo válido nunca é descartado. */
(function () {
  'use strict';
  var core = window.PVCore, BK = window.PVBooks;
  var CONTENT = 'pv4-content', MEDIA = 'pv4-media';
  var APP_VERSION = '__SHELL_HASH__';
  var SHIELD = '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3 4 6v6c0 5 3.4 8 8 9 4.6-1 8-4 8-9V6l-8-3Z"/><path d="m9 12 2 2 4-4"/></svg>';

  /* ---------- utilitários ---------- */
  function $(s, r) { return (r || document).querySelector(s); }
  function $$(s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); }
  function h(tag, attrs, kids) {
    var e = document.createElement(tag);
    Object.keys(attrs || {}).forEach(function (k) {
      var v = attrs[k];
      if (k === 'text') e.textContent = v;
      else if (k.indexOf('on') === 0 && typeof v === 'function') e.addEventListener(k.slice(2), v);
      else if (v !== false && v != null) e.setAttribute(k, v);
    });
    (kids || []).forEach(function (c) { if (c != null) e.appendChild(typeof c === 'string' ? document.createTextNode(c) : c); });
    return e;
  }
  function clear(el) { while (el.firstChild) el.removeChild(el.firstChild); return el; }
  function lsGet(k, d) { try { var v = localStorage.getItem(k); return v === null ? d : v; } catch (e) { return d; } }
  function lsSet(k, v) { try { localStorage.setItem(k, v); } catch (e) { /* sem armazenamento: segue */ } }
  function ssGet(k) { try { return sessionStorage.getItem(k); } catch (e) { return null; } }
  function ssSet(k, v) { try { sessionStorage.setItem(k, v); } catch (e) { /* ignora */ } }
  var toastTimer = null;
  function toast(msg) {
    var t = $('#toast'); t.textContent = msg; t.classList.add('on');
    clearTimeout(toastTimer); toastTimer = setTimeout(function () { t.classList.remove('on'); }, 2200);
  }
  function copy(text, okMsg) {
    var ok = function () { toast(okMsg); };
    var fallback = function () {
      var a = document.createElement('textarea'); a.value = text; a.setAttribute('readonly', ''); a.style.cssText = 'position:fixed;opacity:0;top:0';
      document.body.appendChild(a); a.select();
      try { document.execCommand('copy'); ok(); } catch (e) { toast('Não foi possível copiar.'); }
      a.remove();
    };
    if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(text).then(ok, fallback); else fallback();
  }
  function relPath(url) { var base = new URL('./', location.href).pathname; var p = new URL(url).pathname; return p.indexOf(base) === 0 ? p.slice(base.length) : p.replace(/^\//, ''); }

  /* ---------- configuração (dono, contato, Pix, áudio): arquivo config.json ---------- */
  var cfg = { ownerName: '', year: '', contactEmail: 'contato.palavravivabr@gmail.com', pixKey: '', siteUrl: '', audio: [], audioNomes: [] };
  async function loadConfig() {
    try {
      var r = await fetch('config.json');
      if (r.ok) { var j = await r.json(); Object.keys(cfg).forEach(function (k) { if (j[k] != null) cfg[k] = j[k]; }); }
    } catch (e) { /* sem config: usa o padrão */ }
  }

  /* ---------- aparência ---------- */
  var splashOn = true, appReady = function () { /* definido em bindStatic */ };
  /* cor de destaque discreta (independe do claro/escuro): só troca as variáveis de destaque, os fundos seguem neutros */
  var CORES = ['#8876A8', '#7893B0', '#819989', '#B58F98', '#B09B70', '#777777'];
  function mixCor(hex, alvo, p) {
    var o = '#'; for (var i = 1; i < 7; i += 2) { var a = parseInt(hex.substr(i, 2), 16), b = parseInt(alvo.substr(i, 2), 16), v = Math.round(a + (b - a) * p).toString(16); o += (v.length < 2 ? '0' : '') + v; }
    return o;
  }
  function lumCor(hex) {
    var l = 0; [0.2126, 0.7152, 0.0722].forEach(function (k, i) { var c = parseInt(hex.substr(1 + 2 * i, 2), 16) / 255; l += k * (c <= 0.03928 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4)); });
    return l;
  }
  function aplicarCor(dark) {
    var c = lsGet('pv4-cor', ''), st = document.documentElement.style;
    if (CORES.indexOf(c) < 0) c = '';
    ['--gold', '--gold-ink', '--accent', '--tagink', '--sup'].forEach(function (k) { st.removeProperty(k); });
    if (c) {
      var tx = dark ? mixCor(c, '#ffffff', 0.18) : mixCor(c, '#000000', 0.32), l = lumCor(c);
      st.setProperty('--gold', c); st.setProperty('--gold-ink', (l + 0.05) / 0.066 >= 1.05 / (l + 0.05) ? '#1b1b1b' : '#ffffff');
      st.setProperty('--accent', tx); st.setProperty('--tagink', tx); st.setProperty('--sup', tx);
    }
    $$('#palPop button').forEach(function (b) { b.setAttribute('aria-pressed', String(b.dataset.c === c)); });
  }
  function applyAppearance() {
    var s = parseFloat(lsGet('pv4-fs', '1.125')); if (!(s >= 1 && s <= 1.5)) s = 1.125;
    document.documentElement.style.setProperty('--fs', s + 'rem');
    $$('#fsz button').forEach(function (b) { b.setAttribute('aria-pressed', String(parseFloat(b.dataset.s) === s)); });
    var m = lsGet('pv4-theme', 'auto');
    if (m === 'light' || m === 'dark') document.documentElement.setAttribute('data-theme', m); else { m = 'auto'; document.documentElement.removeAttribute('data-theme'); }
    $$('#thm button').forEach(function (b) { b.setAttribute('aria-pressed', String(b.dataset.m === m)); });
    var dark = m === 'dark' || (m === 'auto' && matchMedia('(prefers-color-scheme: dark)').matches);
    ['#fsRange', '#fsRead'].forEach(function (q) { var r = $(q); if (r && parseFloat(r.value) !== s) r.value = s; });
    aplicarCor(dark);
    var meta = $('meta[name="theme-color"]'); if (meta) meta.setAttribute('content', splashOn ? '#06201a' : (dark ? '#12191A' : '#1F4D43'));
  }

  /* ---------- IndexedDB: destaques, anotações, onde parei (prefixo pv4-) ---------- */
  var dbp = null;
  function db() {
    if (!dbp) dbp = new Promise(function (res, rej) {
      var q = indexedDB.open('pv4-reader', 1);
      q.onupgradeneeded = function () { var d = q.result; ['kv', 'highlights', 'notes'].forEach(function (s) { if (!d.objectStoreNames.contains(s)) d.createObjectStore(s); }); };
      q.onsuccess = function () { res(q.result); }; q.onerror = function () { rej(q.error); };
    });
    return dbp;
  }
  function tx(store, mode, fn) {
    return db().then(function (d) { return new Promise(function (res, rej) {
      var t = d.transaction(store, mode), s = t.objectStore(store), r = fn(s);
      t.oncomplete = function () { res(r && r.result); }; t.onerror = function () { rej(t.error); };
    }); });
  }
  function kvGet(k) { return tx('kv', 'readonly', function (s) { return s.get(k); }).catch(function () { return null; }); }
  function kvSet(k, v) { return tx('kv', 'readwrite', function (s) { return s.put(v, k); }).catch(function () { /* sem DB: segue */ }); }
  function hlAll() {
    return db().then(function (d) { return new Promise(function (res) {
      var out = {}, c = d.transaction('highlights', 'readonly').objectStore('highlights').openCursor();
      c.onsuccess = function () { var cur = c.result; if (cur) { out[cur.key] = true; cur.continue(); } else res(out); };
      c.onerror = function () { res(out); };
    }); }).catch(function () { return {}; });
  }
  function hlSet(key, on) { return tx('highlights', 'readwrite', function (s) { return on ? s.put(true, key) : s.delete(key); }).catch(function () { toast('Não foi possível salvar o destaque neste aparelho.'); }); }
  function exportAll() {
    return db().then(function (d) {
      var out = { app: 'palavra-viva', version: 1, exportedAt: new Date().toISOString(), kv: {}, highlights: {}, notes: {} };
      return Promise.all(['kv', 'highlights', 'notes'].map(function (name) { return new Promise(function (res) {
        var c = d.transaction(name, 'readonly').objectStore(name).openCursor();
        c.onsuccess = function () { var cur = c.result; if (cur) { out[name][cur.key] = cur.value; cur.continue(); } else res(); };
        c.onerror = function () { res(); };
      }); })).then(function () { return out; });
    });
  }
  function importAll(obj) {
    if (!obj || obj.app !== 'palavra-viva' || obj.version !== 1) return Promise.reject(new Error('Arquivo de backup inválido.'));
    /* validação rígida: só objetos simples, chaves e valores de tamanho razoável, nada de chaves perigosas */
    var total = 0;
    function bk(k) { return k === '__proto__' || k === 'constructor' || k === 'prototype'; }
    function ok(v, d) {
      if (v === null || typeof v === 'boolean' || typeof v === 'number') return true;
      if (typeof v === 'string') { total += v.length; return v.length <= 500000; }
      if (d > 6 || typeof v !== 'object') return false;
      if (Array.isArray(v)) return v.length <= 20000 && v.every(function (x) { return ok(x, d + 1); });
      return Object.keys(v).every(function (k) { return !bk(k) && k.length <= 200 && ok(v[k], d + 1); });
    }
    var bad = ['kv', 'highlights', 'notes'].some(function (n) {
      var m = obj[n]; if (m === undefined) return false;
      if (!m || typeof m !== 'object' || Array.isArray(m)) return true;
      var ks = Object.keys(m); if (ks.length > 50000) return true;
      return !ks.every(function (k) { return !bk(k) && k.length <= 200 && ok(m[k], 0); });
    });
    if (bad || total > 20000000) return Promise.reject(new Error('Backup recusado: o arquivo tem conteúdo inesperado.'));
    return db().then(function (d) { return new Promise(function (res, rej) {
      var t = d.transaction(['kv', 'highlights', 'notes'], 'readwrite');
      ['kv', 'highlights', 'notes'].forEach(function (n) { var s = t.objectStore(n); Object.keys(obj[n] || {}).forEach(function (k) { s.put(obj[n][k], k); }); });
      t.oncomplete = res; t.onerror = function () { rej(t.error); };
    }); });
  }

  /* ---------- pacotes de conteúdo ---------- */
  var manifest = null, pkgBy = {};
  function indexManifest() { pkgBy = {}; (manifest.packages || []).forEach(function (p) { pkgBy[p.path] = p; }); }
  /* ---------- traduções bíblicas (BLIVRE é a padrão; as demais vêm em manifest.versions) ---------- */
  var curVer = lsGet('pv_versao', 'blivre');
  function versionsList() {
    var l = (manifest.versions || []).slice();
    if (!l.some(function (v) { return v.padrao; })) { var lic = manifest.license || {}; l.unshift({ id: 'blivre', padrao: true, nome: 'Bíblia Livre', sigla: 'BLIVRE', cobertura: 'completa', licenca: 'CC BY 4.0', licencaUrl: lic.url, credito: lic.text || '', direitos: '' }); }
    return l;
  }
  function versionById(id) { return versionsList().filter(function (v) { return v.id === id; })[0] || null; }
  function activeVersion() { return versionById(curVer) || versionById('blivre'); }
  function bibleOf(v) { return v.padrao ? (manifest.bible || []) : (v.bible || []); }
  function buscaOf(v) { return v.padrao ? manifest.busca : v.busca; }
  function covLabel(v) { return v.cobertura === 'nt' ? 'Somente Novo Testamento (27 livros)' : 'Bíblia completa (66 livros)'; }
  async function loadPackage(entry, offlineOnly) {
    var c = await caches.open(CONTENT);
    var hit = await c.match(entry.path);
    if (hit) {
      var hb = new Uint8Array(await hit.clone().arrayBuffer());
      if ((await core.verifyPackage(hb, entry)).ok) return JSON.parse(new TextDecoder().decode(hb));
      await c.delete(entry.path); // cópia local corrompida: descarta só ela e baixa de novo
    }
    if (offlineOnly) throw new Error('não está neste aparelho');
    var r;
    try { r = await fetch(entry.path, { cache: 'no-store' }); } catch (e) { throw new Error('Sem internet e este conteúdo ainda não foi baixado. Use "Baixar para ler sem internet" quando estiver conectado.'); }
    if (!r.ok) throw new Error('Não foi possível carregar este conteúdo. Tente de novo em instantes.');
    var bytes = new Uint8Array(await r.clone().arrayBuffer());
    var v = await core.verifyPackage(bytes, entry);
    if (!v.ok) throw new Error('Conteúdo recusado: não confere com o manifesto (' + v.reason + ').');
    await c.put(entry.path, r);
    return JSON.parse(new TextDecoder().decode(bytes));
  }
  async function syncManifest() {
    var c = await caches.open(CONTENT);
    var stored = null, s = await c.match('content-manifest.json');
    if (s) { try { stored = await s.json(); } catch (e) { stored = null; } }
    var incoming = null, etag = '';
    try {
      var r = await fetch('content-manifest.json', { cache: 'no-store' });
      if (r.ok) {
        etag = r.headers.get('etag') || '';
        /* mesma versão do que já está guardado: não lê nem interpreta o arquivo grande de novo */
        if (etag && stored && s && s.headers.get('x-etag') === etag) { try { if (r.body) r.body.cancel(); } catch (x) { /* ok */ } return stored; }
        incoming = await r.json();
      }
    } catch (e) { /* offline */ }
    if (!incoming) return stored;
    var cached = (await c.keys()).map(function (rq) { return relPath(rq.url); }).filter(function (p) { return p.indexOf('content/') === 0; });
    var plan = core.planUpdate(stored, incoming, cached);
    if (plan.accept) {
      for (var i = 0; i < plan.remove.length; i++) await c.delete(plan.remove[i]);
      await c.put('content-manifest.json', new Response(JSON.stringify(incoming), { headers: { 'content-type': 'application/json', 'x-etag': etag } }));
      return incoming;
    }
    return stored || incoming;
  }

  /* ---------- catálogo: 66 livros + livros de teste do manifesto ---------- */
  function catalog(vid) {
    var ver = versionById(vid || curVer) || versionById('blivre');
    var avail = {}; bibleOf(ver).forEach(function (b) { avail[b.id] = b; });
    var list = BK.all().map(function (b) {
      var e = avail[b.id];
      return { id: b.id, name: b.name, abbr: b.abbr, testament: b.testament, total: b.chapters, chapters: e ? e.chapters.map(function (c) { return c.n; }) : [], entry: e || null };
    });
    if (ver.padrao) manifest.bible.forEach(function (b) {
      if (!BK.byId(b.id)) list.unshift({ id: b.id, name: b.name, abbr: 'Teste', testament: 'at', total: b.chapters.length, chapters: b.chapters.map(function (c) { return c.n; }), entry: b });
    });
    return list;
  }
  function bookOf(id, vid) { return catalog(vid).filter(function (b) { return b.id === String(id); })[0] || null; }
  function chapterEntry(b, n) { var c = b.entry && b.entry.chapters.filter(function (x) { return x.n === n; })[0]; return c ? pkgBy[c.path] : null; }
  function firstAvailable() {
    var l = catalog().filter(function (b) { return b.chapters.length; });
    return l.length ? { book: l[0].id, chapter: Math.min.apply(null, l[0].chapters) } : null;
  }
  function passagesOf(bookId, n) { return (manifest.passages || []).filter(function (p) { return p.book === String(bookId) && p.chapter === n; }); }
  function featured() {
    var ps = manifest.passages || []; if (!ps.length) return null;
    return ps[Math.floor(Date.now() / 864e5) % ps.length];
  }
  function resolveRef(ref) {
    var p = core.parseRef(ref); if (!p) return null;
    var q = core.normalize(p.name), res = null;
    [curVer, 'blivre'].forEach(function (vid) {
      if (res) return;
      catalog(vid).forEach(function (b) { if (!res && (core.normalize(b.name) === q || core.normalize(b.abbr) === q) && b.chapters.indexOf(p.chapter) >= 0) res = { book: b.id, chapter: p.chapter, verse: p.verse }; });
    });
    return res;
  }

  /* ---------- navegação (o botão voltar do Android funciona dentro do app) ---------- */
  var curState = { v: 'home', d: 0 }, overlay = null;
  var SCREENS = ['home', 'chap', 'read', 'study', 'ens', 'search', 'marks', 'plano', 'menu', 'bible', 'err'];
  function showScreen(v) {
    SCREENS.forEach(function (x) { var s = $('#s-' + x); if (s) s.classList.toggle('on', x === v); });
    var el = $('#s-' + v); if (el) el.scrollTop = 0;
    $$('.nav button[data-tab]').forEach(function (b) { if (b.dataset.tab === (v === 'bible' ? 'home' : v)) b.setAttribute('aria-current', 'page'); else b.removeAttribute('aria-current'); });
  }
  function go(state, replace) {
    var s = {}; Object.keys(state).forEach(function (k) { s[k] = state[k]; });
    if (overlay) { hideOverlayUI(); overlay = null; s.d = curState.d + 1; history.replaceState(s, ''); }
    else if (replace) { s.d = curState.d; history.replaceState(s, ''); }
    else { s.d = curState.d + 1; history.pushState(s, ''); }
    render(s);
  }
  function back() { if (curState.d > 0) history.back(); else go({ v: 'home' }, true); }
  window.addEventListener('popstate', function (e) {
    if (overlay) { hideOverlayUI(); overlay = null; return; }
    var s = e.state && e.state.v ? e.state : { v: 'home', d: 0 };
    render(s);
  });
  function render(s) {
    curState = s;
    try {
      if (s.v === 'chap') viewChap(s); else if (s.v === 'read') viewRead(s); else if (s.v === 'study') viewStudy(s);
      else if (s.v === 'ens') viewEnsinos(); else if (s.v === 'search') viewSearch(); else if (s.v === 'marks') viewMarks(); else if (s.v === 'plano') viewPlano(); else if (s.v === 'bible') viewBible(); else if (s.v === 'menu') viewMenu(); else viewHome();
    } catch (e) { fail(e); }
  }
  function fail(e) {
    var b = clear($('#errBody'));
    b.appendChild(h('h2', { text: 'Algo não deu certo' })); b.appendChild(h('p', { text: e && e.message ? e.message : 'Erro inesperado.' }));
    b.appendChild(h('button', { class: 'btn', type: 'button', text: 'Voltar ao início', onclick: function () { go({ v: 'home' }, true); } }));
    showScreen('err');
  }

  /* overlays: menu lateral e janelas (um só nível de histórico) */
  function openOverlay(kind) {
    if (overlay) history.replaceState({ o: kind, d: curState.d }, ''); else history.pushState({ o: kind, d: curState.d + 1 }, '');
    overlay = kind;
  }
  function hideOverlayUI() {
    $('#drawerBg').classList.remove('on'); $('#modalBg').hidden = true; clear($('#mBody')); $('#app').classList.remove('sheet-open');
    try { document.dispatchEvent(new CustomEvent('pv-overlay-fechou')); } catch (x) { /* ok */ }
  }
  function closeOverlay() { if (overlay) history.back(); }
  function openDrawer() { hideOverlayUI(); openOverlay('drawer'); $('#drawerBg').classList.add('on'); }
  /* opts.sheet: abre como folha na parte de baixo da tela (usado pelas opções de Narração e de Clima de Leitura) */
  function modal(nodes, opts) {
    var m = clear($('#mBody')); nodes.forEach(function (n) { m.appendChild(n); });
    $('#modalBg').classList.toggle('sheet', !!(opts && opts.sheet)); $('#app').classList.toggle('sheet-open', !!(opts && opts.sheet));
    $('#drawerBg').classList.remove('on'); $('#modalBg').hidden = false; openOverlay('modal');
    var f = $('#mClose'); if (f) f.focus();
  }
  function mtag(t, first) { return h('div', { class: 'mtag', style: first ? 'margin-top:30px' : null, text: t }); }

  window.PVApp = { h: h, modal: modal, mtag: mtag, toast: toast, closeOverlay: closeOverlay, trocarTraducao: function () { versionModal(); }, traducao: function () { try { return activeVersion().sigla; } catch (x) { return ''; } }, temVarias: function () { try { return versionsList().length > 1; } catch (x) { return false; } } };

  /* ---------- início ---------- */
  var testament = 'at';
  /* grupos dos livros (por número do livro): títulos pequenos separam a grade longa */
  var GRUPOS = [[1, 'Lei'], [6, 'Históricos'], [18, 'Poéticos'], [23, 'Profetas'], [40, 'Evangelhos e Atos'], [45, 'Cartas'], [66, 'Apocalipse']];
  function grupoDe(id) { var n = parseInt(id, 10), r = ''; GRUPOS.forEach(function (x) { if (n >= x[0]) r = x[1]; }); return r; }
  function drawBooks() {
    var g = clear($('#bgrid')), av = activeVersion(), note = $('#bkNote'), ult = '';
    var bv = $('#bkVer'); if (bv) bv.textContent = 'Texto bíblico: ' + av.nome + ' (' + av.sigla + ')';
    if (note) { note.hidden = av.cobertura !== 'nt'; note.textContent = av.cobertura === 'nt' ? av.sigla + ' contém apenas o Novo Testamento. Para ler o Antigo Testamento, troque a tradução.' : ''; }
    catalog().filter(function (b) { return b.testament === testament; }).forEach(function (b) {
      var have = b.chapters.length > 0, gp = grupoDe(b.id);
      if (gp && gp !== ult) { ult = gp; g.appendChild(h('p', { class: 'bkgrp', text: gp })); }
      g.appendChild(h('button', { class: 'bk', type: 'button', 'aria-disabled': have ? 'false' : 'true', 'aria-label': b.name + (have ? '' : ', sem conteúdo neste aparelho'),
        onclick: function () { if (have) go({ v: 'chap', b: b.id }); else toast(av.cobertura === 'nt' ? av.sigla + ' contém apenas o Novo Testamento. Troque a tradução para ler ' + b.name + '.' : 'O texto de ' + b.name + ' ainda não foi incluído no app.'); } },
        [h('b', { text: b.abbr }), h('span', { text: b.name })]));
    });
  }
  function viewBible() { showScreen('bible'); drawBooks(); }
  async function viewHome() {
    showScreen('home');
    $('#testbar').hidden = manifest.production !== false;
    drawBooks();
    var last = await kvGet('onde-parei'), first = firstAvailable(), r = $('#resume');
    if (last && bookOf(last.book)) { r.hidden = false; $('#resumeEb').textContent = 'Continuar leitura'; $('#resumeTxt').textContent = last.label; r.onclick = function () { go({ v: 'read', b: last.book, c: last.chapter, verse: last.verse }); }; }
    else if (first) { var fb = bookOf(first.book); r.hidden = false; $('#resumeEb').textContent = 'Começar a leitura'; $('#resumeTxt').textContent = fb.name + ' ' + first.chapter; r.onclick = function () { go({ v: 'read', b: first.book, c: first.chapter }); }; }
    else r.hidden = true;
    homeResumeBar(last && bookOf(last.book) ? last : null);
    planoCard(); homeBuild();
    var f = featured(); $('#cardStudy').hidden = !f; $('#railSec').hidden = false;
    var np = (manifest.passages || []).length; $('#cardEns').hidden = !np; $('#ensBanner').hidden = !np; if (np) $('#ensBannerTxt').textContent = 'Aprenda a Palavra: ' + np + (np === 1 ? ' ensino pronto' : ' ensinos prontos');
    if (np) { $('#ensTitle').textContent = 'Aprenda a Palavra'; $('#ensSmall').textContent = np + (np === 1 ? ' ensino pronto' : ' ensinos prontos') + ' · toque para ver'; }
  }
  /* ---------- plano de leitura: Evangelhos em 30 dias (o progresso fica só neste aparelho e entra no backup) ---------- */
  var PLANO = { id: 'ev30', nome: 'Evangelhos em 30 dias', livros: [['40', 28], ['41', 16], ['42', 24], ['43', 21]], porDia: 3 };
  function planoLista() { var l = []; PLANO.livros.forEach(function (x) { var b = bookOf(x[0]); for (var c = 1; c <= x[1]; c++) l.push({ b: x[0], c: c, n: b ? b.name : x[0] }); }); return l; }
  function planoGet() { return kvGet('plano').then(function (p) { return p && p.id === PLANO.id ? p : null; }); }
  function planoFeito(p, it) { return !!(p && p.feitos && p.feitos[it.b + ':' + it.c]); }
  function planoDia(l, p) { var i = 0; while (i < l.length && planoFeito(p, l[i])) i++; return i >= l.length ? { fim: true } : { dia: Math.floor(i / PLANO.porDia) + 1 }; }
  function planoMarcar(b, c, ligar) {
    return planoGet().then(function (p) {
      if (!p) return;
      var k = b + ':' + c; p.feitos = p.feitos || {};
      if (ligar === undefined) ligar = !p.feitos[k];
      if (ligar && p.feitos[k]) return; if (ligar) p.feitos[k] = 1; else delete p.feitos[k];
      var l = planoLista(), dia = planoDia(l, p);
      return kvSet('plano', p).then(function () { if (ligar) toast(dia.fim ? 'Plano concluído. Parabéns!' : 'Capítulo concluído no plano'); });
    });
  }
  function planoCard() {
    var c = $('#planoCard'); if (!c) return;
    planoGet().then(function (p) {
      var l = planoLista(), d = p ? planoDia(l, p) : null, n = p ? l.filter(function (it) { return planoFeito(p, it); }).length : 0, tot = Math.ceil(l.length / PLANO.porDia);
      $('#planoTxt').textContent = !p ? PLANO.nome : d.fim ? 'Plano concluído' : PLANO.nome + ' · dia ' + d.dia + ' de ' + tot;
      $('#planoAcao').textContent = p ? 'Abrir' : 'Começar';
      $('#planoDiaN').textContent = !p ? '30' : d.fim ? '✓' : String(d.dia);
      c.style.setProperty('--p', Math.floor(n / l.length * 100) + '%');
      c.hidden = false; c.onclick = function () { go({ v: 'plano' }); };
    });
  }
  async function viewPlano() {
    showScreen('plano');
    var body = clear($('#planoBody')), p = await planoGet(), l = planoLista(), tot = Math.ceil(l.length / PLANO.porDia);
    function anel(pct, big, small) { return h('div', { class: 'pring', style: '--p:' + pct + '%', 'aria-hidden': 'true' }, [h('b', { text: big }), h('small', { text: small })]); }
    function topo(pct, big, small, titulo, sub) { return h('div', { class: 'phero' }, [anel(pct, big, small), h('div', { class: 'ptxt' }, [h('span', { class: 'eyebrow', text: 'Plano de leitura' }), h('h2', { text: titulo }), h('p', { text: sub })])]); }
    if (!p) {
      body.appendChild(topo(0, '30', 'dias', PLANO.nome, 'Mateus, Marcos, Lucas e João, com cerca de 3 capítulos por dia.'));
      body.appendChild(h('p', { class: 'pnota', text: 'Leia no seu ritmo: se pular um dia, o plano continua de onde você parou. O progresso fica só neste aparelho.' }));
      body.appendChild(h('button', { class: 'btn', type: 'button', text: 'Começar o plano', onclick: function () { kvSet('plano', { id: PLANO.id, feitos: {} }).then(viewPlano); } }));
      return;
    }
    var n = l.filter(function (it) { return planoFeito(p, it); }).length, pct = Math.floor(n / l.length * 100), d = planoDia(l, p);
    body.appendChild(topo(pct, d.fim ? '✓' : String(d.dia), d.fim ? 'fim' : 'de ' + tot, d.fim ? 'Plano concluído' : 'Dia ' + d.dia + ' de ' + tot, n + ' de ' + l.length + ' capítulos · ' + pct + '%'));
    if (d.fim) body.appendChild(h('p', { class: 'pnota', text: 'Você terminou os quatro Evangelhos. Que a Palavra continue a falar com você.' }));
    else {
      body.appendChild(h('h3', { class: 'planosec', text: 'Leitura de hoje' }));
      var ol = h('ol', { class: 'ptl' }), achou = false;
      l.slice((d.dia - 1) * PLANO.porDia, d.dia * PLANO.porDia).forEach(function (it, k) {
        var feito = planoFeito(p, it), est = passagesOf(it.b, it.c), atual = !feito && !achou; if (atual) achou = true;
        ol.appendChild(h('li', { class: 'pstep' + (feito ? ' feito' : atual ? ' atual' : '') }, [
          h('button', { class: 'pdot', type: 'button', 'aria-pressed': feito ? 'true' : 'false', 'aria-label': 'Marcar ' + it.n + ' ' + it.c + ' como lido', text: feito ? '✓' : String(k + 1), onclick: function () { planoMarcar(it.b, it.c).then(viewPlano); } }),
          h('div', { class: 'pbody' }, [
            h('button', { class: 'pler', type: 'button', onclick: function () { go({ v: 'read', b: it.b, c: it.c }); } }, [h('strong', { text: it.n + ' ' + it.c }), h('span', { text: feito ? 'Lido' : atual ? 'Próxima leitura' : 'Toque para ler' })]),
            est.length ? h('button', { class: 'pest', type: 'button', text: 'Ver o estudo ›', onclick: function () { go({ v: 'study', id: est[0].id }); } }) : null])]));
      });
      body.appendChild(ol);
      body.appendChild(h('p', { class: 'pnota', text: 'Toque no círculo para marcar um capítulo como lido. Ao chegar ao fim do texto, ele é marcado sozinho.' }));
    }
    body.appendChild(h('button', { class: 'plink', type: 'button', text: 'Reiniciar o plano', onclick: function () { if (window.confirm('Apagar o progresso deste plano e começar de novo?')) kvSet('plano', null).then(viewPlano); } }));
  }
  function actRead() { kvGet('onde-parei').then(function (last) { var f = firstAvailable(); if (last && bookOf(last.book)) go({ v: 'read', b: last.book, c: last.chapter, verse: last.verse }); else if (f) go({ v: 'read', b: f.book, c: f.chapter }); else toast('Ainda não há texto bíblico neste aparelho.'); }); }
  function actStudy() { var f = featured(); if (f) go({ v: 'study', id: f.id }); else toast('Ainda não há ensino publicado neste aparelho.'); }

  /* ---------- capítulos ---------- */
  function viewChap(s) {
    var b = bookOf(s.b); if (!b) return go({ v: 'home' }, true);
    showScreen('chap'); $('#chapTitle').textContent = b.name;
    var g = clear($('#chapgrid'));
    for (var n = 1; n <= b.total; n++) (function (n) {
      var ok = b.chapters.indexOf(n) >= 0, ens = passagesOf(b.id, n).length > 0;
      g.appendChild(h('button', { type: 'button', class: ens ? 'has' : null, text: String(n), 'aria-label': 'Capítulo ' + n + (ok ? '' : ', sem conteúdo') + (ens ? ', com ensino' : ''), 'aria-disabled': ok ? 'false' : 'true',
        onclick: function () { if (ok) go({ v: 'read', b: b.id, c: n }); else toast('Este capítulo ainda não foi incluído no app.'); } }));
    })(n);
  }

  /* ---------- leitura ---------- */

  /* ---------- leitura em voz alta com a "Voz do celular" (sintetizada; prefere voz masculina) ----------
     Este bloco é só o motor. Os botões e as opções (voz e velocidade) ficam em src/audio-ui.js, que chama window.PVDev. */
  var TTS = { on: false, i: 0, itens: [], voz: null, tk: 0, info: '' };
  function ttsOk() { return 'speechSynthesis' in window && 'SpeechSynthesisUtterance' in window; }
  function vozesPt() {
    return speechSynthesis.getVoices().filter(function (v) { return /^pt/i.test(v.lang); }).sort(function (x, y) { return (/^pt[-_]?br/i.test(y.lang) ? 1 : 0) - (/^pt[-_]?br/i.test(x.lang) ? 1 : 0); });
  }
  var HOMEM = /(\bmale\b|masculin|ptd\b|-ptd|-pte|felipe|antonio|ant[oô]nio|ricardo|daniel|marcos|jorge|luciano|thiago|paulo|\bhomem)/i;
  var MULHER = /(female|feminin|\bptc\b|-afs|-ptf|maria|francisca|luciana|vitoria|vit[oó]ria|fernanda|camila|ana\b|helena|giovanna|leila|yara)/i;
  function escolherVoz() {
    var vs = vozesPt(); if (!vs.length) return null;
    var salva = ''; try { salva = localStorage.getItem('pv_voz') || ''; } catch (x) { /* ok */ }
    var i;
    if (salva) for (i = 0; i < vs.length; i++) if (vs[i].voiceURI === salva) return { v: vs[i], grave: false, manual: true };
    for (i = 0; i < vs.length; i++) if (HOMEM.test(vs[i].name + ' ' + vs[i].voiceURI) && !MULHER.test(vs[i].name + ' ' + vs[i].voiceURI)) return { v: vs[i], grave: false };
    for (i = 0; i < vs.length; i++) if (/pt[-_]?br/i.test(vs[i].lang) && !MULHER.test(vs[i].name + ' ' + vs[i].voiceURI)) return { v: vs[i], grave: true };
    return { v: vs[0], grave: true }; // sem voz masculina identificável: tom mais grave
  }
  function ttsVel() { var v = window.PVNarr && window.PVNarr.vel ? window.PVNarr.vel() : 1; return v > 0 ? v : 1; }
  function ttsAviso() {
    var pausada = false; try { pausada = TTS.on && speechSynthesis.paused; } catch (x) { /* ok */ }
    try { document.dispatchEvent(new CustomEvent('pv-narr', { detail: { src: 'dev', on: TTS.on, playing: TTS.on && !pausada, info: TTS.info } })); } catch (x) { /* ok */ }
  }
  /* troca de velocidade no meio da leitura: para a fala e recomeça no versículo atual */
  function ttsTrocar() {
    if (!TTS.on) return;
    TTS.tk++;
    try { speechSynthesis.cancel(); } catch (x) { /* ok */ }
    setTimeout(function () { if (!TTS.on) return; try { speechSynthesis.resume(); } catch (x) { /* ok */ } ttsFalar(); ttsAviso(); }, 250);
  }
  function ttsStop() {
    var estava = TTS.on;
    TTS.on = false; TTS.tk++; TTS.info = ''; try { speechSynthesis.cancel(); } catch (x) { /* sem voz */ }
    $$('.v.lendo').forEach(function (e) { e.classList.remove('lendo'); });
    if (estava) ttsAviso();
  }
  function ttsFalar() {
    if (!TTS.on) return;
    var el = TTS.itens[TTS.i];
    $$('.v.lendo').forEach(function (e) { e.classList.remove('lendo'); });
    if (!el) { ttsStop(); var nx = $('#chNext'); if (nx && !nx.hidden) { toast('Fim do capítulo'); } return; }
    el.classList.add('lendo'); el.scrollIntoView({ block: 'center', behavior: 'smooth' });
    var tk = TTS.tk;
    var u = new SpeechSynthesisUtterance($('span', el).textContent); // lê só o texto, sem dizer o número do versículo
    u.lang = 'pt-BR'; u.rate = ttsVel(); u.pitch = TTS.voz && TTS.voz.grave ? 0.7 : 0.9;
    if (TTS.voz && TTS.voz.v) { u.voice = TTS.voz.v; u.lang = TTS.voz.v.lang || 'pt-BR'; }
    u.onend = function () { if (tk !== TTS.tk) return; if (TTS.on) { TTS.i++; ttsFalar(); } };
    u.onerror = function (e) { if (tk !== TTS.tk) return; if (e && (e.error === 'canceled' || e.error === 'interrupted')) return; ttsStop(); toast('Não foi possível ler em voz alta neste celular.'); };
    speechSynthesis.speak(u);
  }
  function ttsStart() {
    if (!ttsOk()) return false;
    TTS.itens = $$('#rtext .v'); if (!TTS.itens.length) return false;
    TTS.voz = escolherVoz();
    if (!TTS.voz) { TTS.info = 'Este celular não tem voz em português instalada. Em Configurações > Idioma > Saída de texto para fala, instale o português do Brasil.'; ttsAviso(); return false; }
    TTS.info = ''; TTS.tk++; TTS.i = 0; TTS.on = true;
    try { speechSynthesis.cancel(); } catch (x) { /* ok */ }
    ttsFalar(); ttsAviso(); return true;
  }
  function ttsAlternar() {
    if (!TTS.on) return ttsStart();
    try { if (speechSynthesis.paused) speechSynthesis.resume(); else speechSynthesis.pause(); } catch (x) { /* ok */ }
    ttsAviso(); return true;
  }
  window.PVDev = { available: ttsOk, start: ttsStart, toggle: ttsAlternar, stop: ttsStop, restart: ttsTrocar,
    isOn: function () { return TTS.on; }, isPlaying: function () { try { return TTS.on && !speechSynthesis.paused; } catch (x) { return TTS.on; } }, info: function () { return TTS.info; } };

  function verCredit(v) {
    return v.sigla + (v.direitos ? ' · ' + v.direitos : '') + ' · ' + (v.licenca || '') + ' · ';
  }
  function drawVerBar(v, wanted) {
    var bar = clear($('#verBar')), cred = clear($('#verCred'));
    var name = h('span', { class: 'vname' }, [h('b', { text: v.sigla }), ' · ' + v.nome + (v.cobertura === 'nt' ? ' · só Novo Testamento' : '')]);
    bar.appendChild(name);
    if (versionsList().length > 1) bar.appendChild(h('button', { type: 'button', text: 'Trocar tradução', onclick: versionModal }));
    if (wanted) bar.appendChild(h('p', { class: 'vaviso', style: 'flex-basis:100%;margin:0', text: wanted.sigla + ' não inclui este livro. Mostrando a ' + v.nome + ' (' + v.sigla + ') neste capítulo.' }));
    cred.appendChild(document.createTextNode(verCredit(v)));
    cred.appendChild(h('button', { type: 'button', text: 'créditos e licença', onclick: function () { creditModal(v); } }));
  }
  function creditModal(v) {
    var nodes = [mtag(v.sigla, true), h('h2', { text: v.nome }), h('p', { text: v.credito || '' })];
    if (v.alteracoes) nodes.push(h('p', { style: 'font-size:13px;color:var(--soft)', text: 'Alterações: ' + v.alteracoes }));
    if (v.licencaUrl) nodes.push(h('p', {}, [h('a', { href: v.licencaUrl, rel: 'noopener', target: '_blank', text: 'Ver a licença (' + (v.licenca || '') + ')' })]));
    if (v.fonteUrl) nodes.push(h('p', {}, [h('a', { href: v.fonteUrl, rel: 'noopener', target: '_blank', text: 'Ver a página de direitos da fonte' })]));
    modal(nodes);
  }
  /* a lista do que já está guardado é lida UMA vez por abertura da janela e repartida entre todas as traduções (antes, cada uma refazia a leitura) */
  function cacheHave() {
    return caches.open(CONTENT).then(function (c) { return c.keys(); }).then(function (ks) { return ks.map(function (r) { return relPath(r.url); }); });
  }
  function versionHave(v, have) {
    if (v.padrao) return { have: 1, total: 1 };
    var need = (manifest.packages || []).filter(function (p) { return p.version === v.id; });
    return { have: need.filter(function (p) { return have.indexOf(p.path) >= 0; }).length, total: need.length };
  }
  function setVersion(id) {
    curVer = id; lsSet('pv_versao', id); sidx = null; sidxPath = '';
    var v = activeVersion(); toast('Tradução: ' + v.sigla);
    refreshVerSmall(); closeOverlay();
    setTimeout(function () { if (curState && (curState.v === 'read' || curState.v === 'home' || curState.v === 'chap' || curState.v === 'search')) render(curState); }, 120);
  }
  function refreshVerSmall() { var e = $('#verSmall'); if (e && manifest) e.textContent = activeVersion().sigla; var b = $('#verbtn'); if (b && manifest) b.hidden = versionsList().length < 2; }
  function versionModal() {
    var nodes = [mtag('Tradução bíblica', true), h('h2', { text: 'Escolha a tradução' }), h('p', { class: 'hint', style: 'text-align:center;margin:0 0 12px', text: 'Seus destaques valem para o mesmo versículo em qualquer tradução.' })];
    var busca = h('input', { type: 'search', class: 'vsearch', placeholder: 'Buscar tradução pelo nome ou sigla', 'aria-label': 'Buscar tradução' });
    var lista = h('div', { class: 'vlist' });
    var haveP = cacheHave();
    nodes.push(busca, lista);
    function norm(t) { return String(t || '').toLowerCase().normalize('NFD').replace(new RegExp('[' + String.fromCharCode(768) + '-' + String.fromCharCode(879) + ']', 'g'), ''); }
    function item(v) {
      var on = v.id === activeVersion().id, box = h('div', { class: 'vitem' });
      box.appendChild(h('button', { class: 'vopt', type: 'button', 'aria-pressed': on ? 'true' : 'false', onclick: function () { setVersion(v.id); } }, [
        h('strong', { text: v.nome + ' (' + v.sigla + ')' }),
        h('span', { class: 'vsub', text: (v.edicao ? v.edicao + ' · ' : '') + (v.licenca || '') }),
        h('span', { class: 'vbadge', text: covLabel(v) })]));
      if (v.padrao) {
        /* a tradução padrão já vem guardada no app: aparece na hora, sem esperar verificação */
        var ok0 = h('button', { class: 'vdl', type: 'button', text: 'Já disponível sem internet', disabled: 'disabled' }); ok0.style.opacity = '.7'; box.appendChild(ok0);
      } else {
        /* sem "Verificando…": o botão fica escondido até a resposta chegar (em segundo plano) e só então mostra o que vale para esta tradução */
        var dl = h('button', { class: 'vdl', type: 'button' }); dl.hidden = true;
        box.appendChild(dl);
        haveP.then(function (have) {
          var r = versionHave(v, have); dl.hidden = false;
          if (r.total && r.have === r.total) { dl.textContent = 'Já disponível sem internet'; dl.disabled = true; dl.style.opacity = '.7'; return; }
          dl.textContent = 'Baixar ' + v.sigla + ' para ler sem internet';
          dl.onclick = function () {
            dl.disabled = true; dl.textContent = 'Baixando…';
            downloadAll(function (d, t) { dl.textContent = 'Baixando… ' + d + ' de ' + t; }, function (p) { return p.version === v.id; }).then(function (res) {
              if (res.fails) { dl.disabled = false; dl.textContent = 'Faltaram ' + res.fails + '. Tentar de novo'; } else { dl.textContent = 'Pronto: ' + v.sigla + ' funciona sem internet'; }
            }, function () { dl.disabled = false; dl.textContent = 'Não deu certo. Tentar de novo'; });
          };
        }, function () { dl.textContent = ''; dl.hidden = true; });
      }
      return box;
    }
    function desenhar() {
      var q = norm(busca.value).trim(), todas = versionsList().filter(function (v) { return !q || norm(v.nome + ' ' + v.sigla + ' ' + (v.edicao || '')).indexOf(q) >= 0; });
      clear(lista);
      var grupos = [['Bíblia completa (66 livros)', todas.filter(function (v) { return v.cobertura !== 'nt'; })], ['Somente Novo Testamento (27 livros)', todas.filter(function (v) { return v.cobertura === 'nt'; })]];
      grupos.forEach(function (g) {
        if (!g[1].length) return;
        lista.appendChild(h('h3', { class: 'vgrp', text: g[0] }));
        g[1].forEach(function (v) { lista.appendChild(item(v)); });
      });
      if (!todas.length) lista.appendChild(h('p', { class: 'empty', text: 'Nenhuma tradução com esse nome.' }));
    }
    busca.addEventListener('input', desenhar); desenhar();
    modal(nodes);
  }
  async function viewRead(s) {
    ttsStop();
    var b = bookOf(s.b); if (!b) return go({ v: 'home' }, true);
    var ver = activeVersion(), entry = chapterEntry(b, s.c), fallback = false;
    if (!entry && !ver.padrao) { /* esta tradução não tem o capítulo (ex.: só Novo Testamento): mostra a Bíblia Livre, com aviso */
      var b0 = bookOf(s.b, 'blivre'), e0 = b0 && chapterEntry(b0, s.c);
      if (e0) { b = b0; entry = e0; ver = versionById('blivre'); fallback = true; }
    }
    if (!entry) return go({ v: 'chap', b: b.id }, true);
    showScreen('read'); $('#readTitle').textContent = b.name + ' ' + s.c;
    try { document.dispatchEvent(new CustomEvent('pv-leitura')); } catch (x) { /* ok */ } /* avisa a barra de áudio (src/audio-ui.js) que o capítulo mudou */
    drawVerBar(ver, fallback ? activeVersion() : null);
    var box = clear($('#rtext')); clear($('#studyList'));
    box.appendChild(h('p', { class: 'empty', text: 'Carregando…' }));
    var avail = b.chapters.slice().sort(function (x, y) { return x - y; }), i = avail.indexOf(s.c);
    var prev = $('#chPrev'), next = $('#chNext');
    prev.hidden = i <= 0; next.hidden = i >= avail.length - 1;
    prev.onclick = function () { go({ v: 'read', b: b.id, c: avail[i - 1] }, true); };
    next.onclick = function () { go({ v: 'read', b: b.id, c: avail[i + 1] }, true); };
    var pkg;
    try { pkg = await loadPackage(entry); }
    catch (e) {
      clear(box);
      box.appendChild(h('div', { class: 'err' }, [h('p', { text: e.message }), h('button', { class: 'btn', type: 'button', text: 'Tentar de novo', onclick: function () { viewRead(s); } })]));
      return;
    }
    if (curState !== s) return; // o usuário já foi para outra tela
    kvSet('onde-parei', s.verse ? { book: b.id, chapter: s.c, verse: s.verse, label: b.name + ' ' + s.c + ':' + s.verse } : { book: b.id, chapter: s.c, label: b.name + ' ' + s.c });
    var marks = await hlAll();
    clear(box);
    if (pkg.titulo) box.appendChild(h('p', { class: 'ptitulo', text: pkg.titulo }));
    if (!lsGet('pv4-dica-marca', '')) box.appendChild(h('div', { class: 'dica' }, [h('span', { text: 'Dica: toque num versículo para destacar, copiar, compartilhar ou anotar. Tudo fica guardado em Minha Palavra. Deslize para os lados para trocar de capítulo.' }), h('button', { type: 'button', text: 'Entendi', onclick: function (e) { lsSet('pv4-dica-marca', '1'); var d = e.currentTarget.parentNode; d.parentNode.removeChild(d); } })]));
    pkg.verses.forEach(function (v) {
      var key = b.id + ':' + s.c + ':' + v.n;
      var vl = v.ate ? v.n + '-' + v.ate : String(v.n);
      var btn = h('button', { class: 'v', type: 'button', 'data-n': String(v.n), 'aria-pressed': marks[key] ? 'true' : 'false', 'aria-label': 'Versículo ' + vl + '. Toque para abrir as opções.' },
        [h('sup', { text: vl }), h('span', { text: v.t })]);
      btn.addEventListener('click', function () { versoMenu(b, s.c, v, key, btn, ver); });
      box.appendChild(btn);
    });
    passagesOf(b.id, s.c).forEach(function (p) {
      $('#studyList').appendChild(h('button', { class: 'entender', type: 'button', style: '--img:url(assets/hero-bible.jpg)', onclick: function () { go({ v: 'study', id: p.id }); } },
        [h('span', {}, [h('strong', { text: 'Entender ' + p.ref })]), h('span', { class: 'cta', style: 'min-height:40px', text: 'Abrir' })]));
    });
    planoGet().then(function (pl) {
      if (!pl || !('IntersectionObserver' in window)) return;
      var fim = $('.row2'), t0 = Date.now(); if (!fim) return;
      var ob = new IntersectionObserver(function (es) {
        if (!es[0].isIntersecting) return; ob.disconnect();
        setTimeout(function () { if (curState === s) planoMarcar(b.id, s.c, true); }, Math.max(0, 6000 - (Date.now() - t0)));
      }, { threshold: 0.6 });
      ob.observe(fim);
    });
    if ('IntersectionObserver' in window) {
      var fim2 = $('.row2'), t1 = Date.now();
      if (fim2) {
        var ob2 = new IntersectionObserver(function (es) {
          if (!es[0].isIntersecting) return; ob2.disconnect();
          setTimeout(function () { if (curState === s) lidoMarcar(b.id, s.c); }, Math.max(0, 6000 - (Date.now() - t1)));
        }, { threshold: 0.6 });
        ob2.observe(fim2);
      }
    }
    if (s.verse) { var t = $('.v[data-n="' + s.verse + '"]', box); if (t) { t.scrollIntoView({ block: 'center' }); t.classList.add('flash'); } }
  }

  /* ---------- ensinos prontos (lista por livro) ---------- */
  function viewEnsinos() {
    showScreen('ens');
    var body = clear($('#ensBody')), ps = manifest.passages || [];
    if (!ps.length) { body.appendChild(h('p', { class: 'empty', text: 'Os primeiros ensinos ainda estão sendo preparados.' })); return; }
    body.appendChild(h('p', { class: 'lead', text: 'Cada ensino ajuda você a ler, entender, ver Cristo no texto e viver a Palavra. Toque para abrir.' }));
    var H3 = window.PVHome3;
    if (H3 && H3.grupoDe) return viewEnsinosGrade(body, ps, H3);
    var order = {}; catalog().forEach(function (b, i) { order[b.id] = i; });
    var by = {};
    ps.forEach(function (p) { (by[p.book] = by[p.book] || []).push(p); });
    Object.keys(by).sort(function (x, y) { return (order[x] - order[y]); }).forEach(function (bid) {
      var bk = bookOf(bid), grp = h('div', { class: 'ensgroup' }, [h('h3', { text: bk ? bk.name : bid })]), list = h('div', { class: 'list' });
      by[bid].sort(function (x, y) { return (x.chapter - y.chapter) || String(x.id).localeCompare(String(y.id), undefined, { numeric: true }); }).forEach(function (p) {
        list.appendChild(h('button', { class: 'hit', type: 'button', onclick: function () { go({ v: 'study', id: p.id }); } }, [h('strong', { text: p.titulo || p.ref }), h('span', { class: 'ref-mini', text: p.ref })]));
      });
      grp.appendChild(list); body.appendChild(grp);
    });
  }

  /* página Estudos em grade: filtros por grupo de livros e cartões com a foto do mapa (ou capa desenhada) */
  function viewEnsinosGrade(body, ps, H3) {
    var order = {}; catalog().forEach(function (b, i) { order[b.id] = i; });
    var lista = ps.slice().sort(function (x, y) { return (order[x.book] - order[y.book]) || (x.chapter - y.chapter) || String(x.id).localeCompare(String(y.id), undefined, { numeric: true }); });
    var presentes = H3.GRUPOS.filter(function (g) { return lista.some(function (p) { var q = H3.grupoDe(p.book); return q && q.id === g.id; }); });
    var filtro = 'todos', mapa = null;
    var chips = h('div', { class: 'ensfil', role: 'group', 'aria-label': 'Filtrar estudos por grupo de livros' });
    var grid = h('div', { class: 'ensgrid' });
    body.appendChild(chips); body.appendChild(grid);
    var pinta = function () {
      clear(chips); clear(grid);
      [{ id: 'todos', nome: 'Todos' }].concat(presentes).forEach(function (g) {
        chips.appendChild(h('button', { class: 'chip' + (filtro === g.id ? ' on' : ''), type: 'button', 'aria-pressed': filtro === g.id ? 'true' : 'false', text: g.nome, onclick: function () { filtro = g.id; pinta(); } }));
      });
      lista.filter(function (p) { if (filtro === 'todos') return true; var q = H3.grupoDe(p.book); return q && q.id === filtro; }).forEach(function (p) {
        var bk = bookOf(p.book), nome = bk ? bk.name : livroNome(p.ref);
        var foto = H3.capaFoto(mapa, p.id);
        var cv = h('span', { class: 'cv' });
        cv.style.backgroundImage = (foto ? 'url("' + foto + '"),' : '') + 'url("' + H3.capaSvg(null, nome) + '")';
        cv.appendChild(h('b', { text: nome }));
        var c = h('button', { class: 'estc', type: 'button', 'aria-label': 'Abrir estudo: ' + (p.titulo || p.ref) + ' (' + p.ref + ')', onclick: function () { go({ v: 'study', id: p.id }); } }, [cv, h('small', { text: p.titulo || p.ref })]);
        grid.appendChild(c);
      });
    };
    pinta();
    /* o mapa de fotos é opcional: sem ele, ficam as capas desenhadas */
    fetch('assets/capas-map.json').then(function (r) { return r.ok ? r.json() : null; }).catch(function () { return null; }).then(function (m) { mapa = m; pinta(); });
  }
  function livroNome(ref) { return String(ref || '').replace(/\s+\d+.*$/, '').trim(); }

  /* ---------- estudo em camadas ---------- */
  async function viewStudy(s) {
    var meta = (manifest.passages || []).filter(function (p) { return p.id === s.id; })[0];
    if (!meta) return go({ v: 'home' }, true);
    showScreen('study'); $('#studyTitle').textContent = meta.ref;
    var tabs = clear($('#depth')), panels = clear($('#panels')), head = clear($('#studyHead'));
    panels.appendChild(h('p', { class: 'empty', text: 'Carregando…' }));
    var p;
    try { p = await loadPackage(pkgBy[meta.path]); }
    catch (e) { clear(panels); panels.appendChild(h('div', { class: 'err' }, [h('p', { text: e.message }), h('button', { class: 'btn', type: 'button', text: 'Tentar de novo', onclick: function () { viewStudy(s); } })])); return; }
    if (curState !== s) return;
    var refs = (p.refs || []).map(function (r) { return { text: r, to: resolveRef(r) }; }).filter(function (r) { return r.to; });
    var shown = core.visibleTabs({ verses: p.verses, entender: p.entender, ligar: p.ligar, viver: p.viver, guarde: p.guarde, ore: p.ore, quiz: p.quiz, refs: refs });
    if (p.titulo) { head.appendChild(h('h2', { class: 'stitle', text: p.titulo })); }
    head.appendChild(h('button', { class: 'btn alt sharebtn', type: 'button', text: 'Compartilhar este estudo', onclick: function () { shareStudy(meta.id); } }));
    var NAMES = { ler: 'Ler', entender: 'Entender', ligar: 'Ligar ao evangelho', viver: 'Viver', testar: 'Testar', aprofundar: 'Aprofundar' };
    var stamp = function () {
      var st = core.stampText(p); if (!st) return null;
      var ic = h('span', { 'aria-hidden': 'true' }); ic.innerHTML = SHIELD; /* SVG fixo do próprio app, sem dados externos */
      return h('div', { class: 'stamp' }, [ic, h('span', { text: st })]);
    };
    var build = {
      ler: function () {
        var n = [];
        if (p.pergunta) n.push(h('div', { class: 'pergunta' }, [h('b', { text: 'Para pensar antes de ler' }), h('p', { text: p.pergunta })]));
        n.push(h('span', { class: 'tag', text: 'Texto bíblico · Bíblia Livre (BLIVRE)' }));
        n.push(h('div', { class: 'text' }, p.verses.map(function (v) { return h('span', { class: 'v' }, [h('sup', { text: String(v.n) }), h('span', { text: v.t })]); })));
        return n;
      },
      entender: function () {
        return [
          h('div', { class: 'cardx study' }, String(p.entender).split(/\n\s*\n/).map(function (t) { return h('p', { text: t.trim(), style: 'margin-bottom:10px' }); })), stamp()];
      },
      ligar: function () {
        return [
          h('div', { class: 'seal' }, [h('b', { text: p.ligar.selo === true ? 'Cristo neste texto' : 'Ligar ao evangelho' }), h('p', { text: p.ligar.texto })]), stamp()];
      },
      viver: function () {
        var n = [];
        if (p.viver) n.push(h('div', { class: 'cardx study viver' }, [h('div', { class: 'sub', text: 'Como viver' })].concat(String(p.viver).split(/\n\s*\n/).map(function (t) { return h('p', { text: t.trim(), style: 'margin-bottom:8px' }); }))));
        if (p.guarde) n.push(h('div', { class: 'guarde' }, [h('div', { class: 'mtag', style: 'margin:0 0 6px', text: 'Guarde no coração' }), h('p', { text: p.guarde }), h('button', { class: 'btn alt sharebtn', type: 'button', text: 'Compartilhar cartão', onclick: function () { shareCard(meta.id, p.guarde); } })]));
        if (p.ore) n.push(h('div', { class: 'cardx study viver' }, [h('div', { class: 'sub', text: 'Ore' }), h('p', { text: p.ore })]));
        n.push(stamp()); return n;
      },
      testar: function () {
        var qz = p.quiz, wrap = h('div', { class: 'quiz' }), fb = h('div', { class: 'fb', hidden: true, role: 'status' }), done = false;
        wrap.appendChild(h('p', { class: 'q', text: qz.pergunta }));
        var btns = qz.opcoes.map(function (o, i) {
          var b = h('button', { class: 'opt', type: 'button', text: o, onclick: function () {
            if (done) return;
            if (i === qz.certa) { done = true; b.classList.add('ok'); fb.hidden = false; fb.textContent = 'Isso mesmo! ' + (qz.explicacao || ''); }
            else { b.classList.add('no'); b.disabled = true; fb.hidden = false; fb.textContent = 'Quase. Releia o texto na aba Ler e tente de novo.'; }
          } });
          wrap.appendChild(b); return b;
        });
        wrap.appendChild(fb);
        return [h('span', { class: 'tag app', text: 'Teste o que você aprendeu' }), h('div', { class: 'cardx study' }, [wrap]), stamp()];
      },
      aprofundar: function () {
        return [h('span', { class: 'tag', text: 'Texto bíblico' }),
          h('div', { class: 'cardx study' }, [h('p', { text: 'Toque para ler a outra passagem. O botão voltar traz você de volta aqui.', style: 'margin-bottom:12px' }),
            h('div', { class: 'refs' }, refs.map(function (r) { return h('button', { class: 'ref', type: 'button', text: r.text, onclick: function () { go({ v: 'read', b: r.to.book, c: r.to.chapter, verse: r.to.verse }); } }); }))])];
      }
    };
    clear(panels);
    shown.forEach(function (name, i) {
      tabs.appendChild(h('button', { class: 'dtab', type: 'button', role: 'tab', 'aria-selected': i === 0 ? 'true' : 'false', 'data-p': name, text: NAMES[name], onclick: function () { select(name); } }));
      var pn = h('div', { class: 'panel study' + (i === 0 ? ' on' : ''), id: 'p-' + name, role: 'tabpanel' }, build[name]());
      panels.appendChild(pn);
    });
    function select(name) {
      $$('.dtab', tabs).forEach(function (t) { t.setAttribute('aria-selected', String(t.dataset.p === name)); });
      $$('.panel', panels).forEach(function (x) { x.classList.toggle('on', x.id === 'p-' + name); });
    }
  }

  /* ---------- busca ---------- */
  var searchToken = 0, sidx = null, sidxPath = '', pidx = null, pidxKey = '';
  function viewSearch() { showScreen('search'); var q = $('#q'); setTimeout(function () { q.focus(); }, 60); if (q.value) runSearch(q.value); }
  async function ensureIndex() {
    var bpath = buscaOf(activeVersion());
    if (!bpath) return null;
    if (sidx && sidxPath === bpath) return sidx;
    var pkg = await loadPackage(pkgBy[bpath]);
    sidx = core.searchPrepare(pkg.rows); sidxPath = bpath;
    return sidx;
  }
  function passageIndex() {
    var ps = manifest.passages || [], key = manifest.generation + ':' + ps.length;
    if (pidx && pidxKey === key) return pidx;
    pidx = core.searchPrepare(ps.map(function (p) { return [p.id, 0, 0, (p.titulo || '') + ' ' + p.ref + ' ' + (p.temas || []).join(' ')]; })); pidxKey = key;
    return pidx;
  }
  function snippet(text, ranges) {
    var m = ranges[0] || { start: 0, end: 0 }, from = Math.max(0, m.start - 70), to = Math.min(text.length, Math.max(m.end, m.start) + 110), out = [], pos = from;
    if (from > 0) { var sp = text.indexOf(' ', from); if (sp >= 0 && sp < m.start) from = pos = sp + 1; out.push('…'); }
    if (to < text.length) { var sp2 = text.lastIndexOf(' ', to); if (sp2 > m.end) to = sp2; }
    ranges.forEach(function (r) { if (r.start < pos || r.start >= to) return; out.push(text.slice(pos, r.start)); out.push(h('mark', { text: text.slice(r.start, r.end) })); pos = r.end; });
    out.push(text.slice(pos, to)); if (to < text.length) out.push('…');
    return out;
  }
  async function runSearch(raw) {
    var token = ++searchToken, q = raw.trim(), box = clear($('#results'));
    if (q.length < 2) return;
    var nq = core.normalize(q), list = h('div', { class: 'list' });
    /* 1) referência direta: "João 3:16" */
    var ref = core.parseRef(q), to = ref ? resolveRef(q) : null;
    if (to) { var rb = bookOf(to.book); list.appendChild(h('button', { class: 'item', type: 'button', onclick: function () { go({ v: 'read', b: to.book, c: to.chapter, verse: to.verse }); } }, [h('strong', { text: 'Abrir ' + rb.name + ' ' + to.chapter + (to.verse ? ':' + to.verse : '') }), h('small', { text: 'Ir direto' })])); }
    /* 2) livros */
    catalog().filter(function (b) { return core.normalize(b.name).indexOf(nq) === 0 || core.normalize(b.abbr) === nq || (nq.length >= 3 && core.normalize(b.name).split(' ').some(function (w) { return w.indexOf(nq) === 0; })); }).slice(0, 6).forEach(function (b) {
      list.appendChild(h('button', { class: 'item', type: 'button', onclick: function () { if (b.chapters.length) go({ v: 'chap', b: b.id }); else toast('O texto de ' + b.name + ' ainda não foi incluído no app.'); } }, [h('strong', { text: b.name }), h('small', { text: b.chapters.length ? 'Livro' : 'Sem conteúdo neste aparelho' })]));
    });
    if (list.children.length) box.appendChild(list);
    /* 3) ensinos do app */
    var pr = core.searchRun(passageIndex(), q).hits.slice(0, 6), ps = manifest.passages || [];
    if (pr.length) {
      box.appendChild(h('p', { class: 'count', text: 'Ensinos sobre "' + q + '"' }));
      var pl = h('div', { class: 'list' });
      pr.forEach(function (x) { var p = ps[x.i]; pl.appendChild(h('button', { class: 'hit', type: 'button', onclick: function () { go({ v: 'study', id: p.id }); } }, [h('strong', { text: p.titulo || p.ref }), h('span', { text: p.titulo ? p.ref : '' })])); });
      box.appendChild(pl);
    }
    /* 4) versículos: palavra inteira (e suas formas), não pedaços de outras palavras */
    var info = h('p', { class: 'count', text: 'Buscando…' }); box.appendChild(info);
    var hitsBox = h('div', { class: 'list' }); box.appendChild(hitsBox);
    var idx;
    try { idx = await ensureIndex(); } catch (e) { idx = null; }
    if (token !== searchToken) return;
    if (!idx) { info.textContent = 'A busca no texto ainda não está neste aparelho. Conecte-se à internet uma vez e abra o app de novo.'; return; }
    var res = core.searchRun(idx, q), shown = 0, PAGE = 30, more = h('button', { class: 'btn', type: 'button', style: 'margin:12px auto 0' });
    function names(id) { var b = BK.byId(id); return b ? b.name : id; }
    function draw() {
      var end = Math.min(res.hits.length, shown + PAGE);
      for (var k = shown; k < end; k++) (function (row) {
        var t = row[3];
        hitsBox.appendChild(h('button', { class: 'hit', type: 'button', onclick: function () { go({ v: 'read', b: row[0], c: row[1], verse: row[2] }); } },
          [h('strong', { text: names(row[0]) + ' ' + row[1] + ':' + row[2] }), h('span', {}, snippet(t, core.highlightRanges(t, q)))]));
      })(idx.rows[res.hits[k].i]);
      shown = end; more.style.display = shown >= res.hits.length ? 'none' : 'block'; more.textContent = 'Mostrar mais ' + Math.min(PAGE, res.hits.length - shown);
    }
    more.onclick = draw;
    info.textContent = res.hits.length ? res.hits.length + (res.hits.length === 1 ? ' versículo' : ' versículos') + ' em ' + activeVersion().sigla + ' com "' + q + '"' + (res.q.tokens.length > 1 && !res.q.phrase ? ' (todas as palavras)' : '') + '.'
      : (list.children.length || pr.length ? '' : 'Nada encontrado para "' + q + '". Tente outra palavra ou escreva entre aspas uma frase exata.');
    draw(); box.appendChild(more);
  }

  /* ---------- Jornada: registro dos capítulos lidos (guardado só neste aparelho, em kv "historico"; entra no backup) ---------- */
  function lidoMarcar(book, cap) {
    return kvGet('historico').then(function (hist) { return kvSet('historico', core.registrarLeitura(hist, book, cap, Date.now())); });
  }

  /* ---------- menu do versículo (toque no versículo durante a leitura) ---------- */
  function shareCardVerso(ref, frase) {
    var texto = '“' + frase + '” (' + ref + ')', url = baseUrl();
    makeCard(frase, ref).then(function (blob) {
      var f = new File([blob], 'cartao-biblico.png', { type: 'image/png' });
      if (navigator.canShare && navigator.canShare({ files: [f] })) navigator.share({ files: [f], title: ref, text: texto + ' ' + url }).catch(function () { /* cancelado */ });
      else send({ title: ref, text: texto, url: url }, 'Texto copiado');
    }, function () { send({ title: ref, text: texto, url: url }, 'Texto copiado'); });
  }
  function versoMenu(b, cap, v, key, btn, ver) {
    var vl = v.ate ? v.n + '-' + v.ate : String(v.n), ref = b.name + ' ' + cap + ':' + vl;
    var credito = (ver && ver.sigla ? ' ' + ver.sigla + ' · ' : ' ') + APP_NAME;
    var texto = core.textoVerso(b.name, cap, vl, v.t) + credito;
    var on = btn.getAttribute('aria-pressed') === 'true';
    kvSet('onde-parei', { book: b.id, chapter: cap, verse: v.n, label: ref });
    function acao(rot, fn) { return h('button', { class: 'vmact', type: 'button', text: rot, onclick: fn }); }
    modal([
      mtag(ref, true),
      h('p', { class: 'vmtxt', text: v.t }),
      h('div', { class: 'vmenu' }, [
        acao(on ? 'Remover destaque' : 'Destacar', function () { var novo = !on; btn.setAttribute('aria-pressed', novo ? 'true' : 'false'); hlSet(key, novo); closeOverlay(); toast(novo ? 'Versículo destacado' : 'Destaque removido'); }),
        acao('Copiar', function () { copy(texto, 'Versículo copiado'); closeOverlay(); }),
        acao('Compartilhar', function () { send({ title: ref, text: texto + ':', url: baseUrl() }); }),
        acao('Compartilhar cartão', function () { shareCardVerso(ref, v.t); }),
        acao('Anotar', function () { notasAbrir({ ref: ref, vk: key }); })
      ])
    ]);
  }

  /* ---------- Minha Palavra: Jornada, Destaques e Notas ---------- */
  var marksTab = 'jornada';
  function aposNota() { if (curState && curState.v === 'marks' && marksTab === 'notas') viewMarks(); }
  async function viewMarks() {
    showScreen('marks');
    var body = clear($('#marksBody')), tab = marksTab;
    var abas = [['jornada', 'Jornada'], ['destaques', 'Destaques'], ['notas', 'Notas']];
    body.appendChild(h('div', { class: 'mseg', role: 'tablist', 'aria-label': 'Minha Palavra' }, abas.map(function (a) {
      return h('button', { type: 'button', role: 'tab', 'aria-selected': String(tab === a[0]), text: a[1], onclick: function () { if (marksTab !== a[0]) { marksTab = a[0]; viewMarks(); } } });
    })));
    var area = h('div', { class: 'marksarea' }); body.appendChild(area);
    try {
      if (tab === 'destaques') await marksDestaques(area); else if (tab === 'notas') await marksNotas(area); else await marksJornada(area);
    } catch (e) { area.appendChild(h('p', { class: 'empty', text: 'Não foi possível carregar esta lista neste aparelho.' })); }
  }
  function marksBusca(rotulo) { return h('input', { class: 'msearch', type: 'search', placeholder: rotulo, 'aria-label': rotulo, autocomplete: 'off' }); }

  async function marksDestaques(area) {
    var keys = Object.keys(await hlAll());
    if (!keys.length) {
      area.appendChild(h('div', { class: 'empty' }, [h('p', { text: 'Você ainda não destacou nenhum versículo. Toque em um versículo durante a leitura e escolha Destacar para guardá-lo aqui.' }), h('button', { class: 'btn', type: 'button', text: 'Ir ler', onclick: actRead })]));
      return;
    }
    var order = {}; catalog().forEach(function (b, i) { order[b.id] = i; });
    var items = keys.map(function (k) { var p = k.split(':'); return { b: p[0], c: parseInt(p[1], 10), v: parseInt(p[2], 10) }; })
      .filter(function (x) { return bookOf(x.b); })
      .sort(function (a, b) { return (order[a.b] - order[b.b]) || (a.c - b.c) || (a.v - b.v); });
    var busca = marksBusca('Buscar nos destaques'), conta = h('p', { class: 'count' }), list = h('div', { class: 'list' }), rows = [];
    area.appendChild(busca); area.appendChild(conta); area.appendChild(list);
    for (var i = 0; i < items.length; i++) {
      var it = items[i], bk = bookOf(it.b), text = '';
      try { var e = chapterEntry(bk, it.c); if (!e) { var bk0 = bookOf(it.b, 'blivre'); e = bk0 && chapterEntry(bk0, it.c); } if (e) { var pkg = await loadPackage(e, true); var vv = pkg.verses.filter(function (x) { return x.n === it.v; })[0]; if (vv) text = vv.t; } } catch (x) { /* sem o texto neste aparelho: mostra só a referência */ }
      var node = (function (it, bk, text) {
        return h('button', { class: 'hit', type: 'button', onclick: function () { go({ v: 'read', b: it.b, c: it.c, verse: it.v }); } }, [h('strong', { text: bk.name + ' ' + it.c + ':' + it.v }), text ? h('span', { text: text }) : null]);
      })(it, bk, text);
      rows.push({ node: node, hay: core.normalize(bk.name + ' ' + it.c + ':' + it.v + ' ' + text) });
      list.appendChild(node);
    }
    function filtra() {
      var t = core.normalize(busca.value).trim(), n = 0;
      rows.forEach(function (r) { var ok = !t || r.hay.indexOf(t) >= 0; r.node.hidden = !ok; if (ok) n++; });
      conta.textContent = t ? n + (n === 1 ? ' resultado' : ' resultados') : items.length + (items.length === 1 ? ' versículo destacado' : ' versículos destacados');
    }
    busca.addEventListener('input', filtra); filtra();
  }

  async function marksNotas(area) {
    area.appendChild(h('button', { class: 'btn', type: 'button', text: 'Nova anotação', onclick: function () { notasAbrir(); } }));
    var l = await notasLer();
    if (!l.length) { area.appendChild(h('p', { class: 'empty', text: 'Você ainda não tem anotações. Toque em um versículo durante a leitura e escolha Anotar, ou use o botão acima.' })); return; }
    var busca = marksBusca('Buscar nas anotações'), list = h('div', { class: 'nlist' }), rows = [];
    area.appendChild(busca); area.appendChild(list);
    l.forEach(function (n) {
      var d = new Date(n.editado || n.criado || 0).toLocaleDateString('pt-BR');
      var node = h('div', { class: 'nitem' }, [
        h('div', { class: 'nmeta', text: d + (n.ref ? ' · ' + n.ref : '') }),
        h('p', { class: 'ntexto', text: n.texto }),
        h('div', { class: 'row' }, [
          n.estudo && metaOf(n.estudo) ? h('button', { class: 'nbtn', type: 'button', text: 'Abrir estudo', onclick: function () { go({ v: 'study', id: n.estudo }); } }) : null,
          n.vk ? h('button', { class: 'nbtn', type: 'button', text: 'Ler versículo', onclick: function () { var q = n.vk.split(':'); go({ v: 'read', b: q[0], c: parseInt(q[1], 10), verse: parseInt(q[2], 10) }); } }) : null,
          h('button', { class: 'nbtn', type: 'button', text: 'Editar', onclick: function () { notasAbrir({ edit: n }); } }),
          h('button', { class: 'nbtn', type: 'button', text: 'Excluir', onclick: function () { if (window.confirm('Excluir esta anotação?')) notaApagar(n.id).then(function () { viewMarks(); }); } })])]);
      rows.push({ node: node, hay: core.normalize((n.ref || '') + ' ' + n.texto) });
      list.appendChild(node);
    });
    busca.addEventListener('input', function () {
      var t = core.normalize(busca.value).trim();
      rows.forEach(function (r) { r.node.hidden = !!t && r.hay.indexOf(t) < 0; });
    });
  }

  async function marksJornada(area) {
    var hist = (await kvGet('historico')) || {}, last = await kvGet('onde-parei'), pl = await planoGet();
    var livros = catalog().map(function (b) { return { id: b.id, chapters: b.chapters }; });
    var lidos = hist.lidos || {}, dias = hist.dias || {}, hoje = core.diaStr(Date.now());
    var nCap = core.capitulosLidos(lidos, livros), nLiv = core.livrosConcluidos(lidos, livros), seq = core.diasSeguidos(dias, hoje);
    if (last && bookOf(last.book)) {
      area.appendChild(h('button', { class: 'resume', type: 'button', style: 'margin:0;width:100%', onclick: function () { go({ v: 'read', b: last.book, c: last.chapter, verse: last.verse }); } },
        [h('span', { class: 't' }, [h('span', { class: 'eyebrow', text: 'Continuar leitura' }), h('strong', { text: last.label })]), h('span', { class: 'ler', text: 'Ler' })]));
    }
    function metrica(valor, rotulo, fn) {
      return h(fn ? 'button' : 'div', fn ? { class: 'jm', type: 'button', onclick: fn } : { class: 'jm' }, [h('b', { text: String(valor) }), h('small', { text: rotulo })]);
    }
    var plano = null;
    if (pl) { var lp = planoLista(), nf = lp.filter(function (it) { return planoFeito(pl, it); }).length; plano = metrica(nf + ' de ' + lp.length, PLANO.nome, function () { go({ v: 'plano' }); }); }
    else plano = metrica('Não iniciado', PLANO.nome, function () { go({ v: 'plano' }); });
    area.appendChild(h('div', { class: 'jgrid' }, [
      metrica(nCap, nCap === 1 ? 'Capítulo lido' : 'Capítulos lidos'),
      metrica(nLiv, nLiv === 1 ? 'Livro concluído' : 'Livros concluídos'),
      metrica(seq, seq === 1 ? 'Dia seguido' : 'Dias seguidos'),
      plano]));
    var u = core.ultimosDias(dias, hoje, 7), lidosSemana = u.filter(function (x) { return x.lido; }).length, ini = ['D', 'S', 'T', 'Q', 'Q', 'S', 'S'];
    area.appendChild(h('div', { class: 'jcard' }, [
      h('div', { class: 'eyebrow', text: 'Últimos 7 dias' }),
      h('div', { class: 'jdias', role: 'img', 'aria-label': 'Você leu em ' + lidosSemana + ' dos últimos 7 dias' }, u.map(function (x) { return h('i', { class: x.lido ? 'd' : '', text: ini[x.sem] }); })),
      h('p', { class: 'hint', text: nCap ? 'Seu ritmo é só seu, sem comparação com ninguém.' : 'Seu progresso passa a ser guardado agora: leia um capítulo até o fim e ele aparece aqui.' })]));
    var rec = core.recentes(lidos, 5).filter(function (x) { return bookOf(x.b); });
    if (rec.length) {
      area.appendChild(h('div', { class: 'eyebrow', style: 'margin:14px 0 8px', text: 'Lidos recentemente' }));
      var lista = h('div', { class: 'list' }); area.appendChild(lista);
      rec.forEach(function (x) {
        lista.appendChild(h('button', { class: 'hit', type: 'button', onclick: function () { go({ v: 'read', b: x.b, c: x.c }); } }, [h('strong', { text: bookOf(x.b).name + ' ' + x.c }), h('span', { text: new Date(x.ts).toLocaleDateString('pt-BR') })]));
      });
    }
    if (!nCap && !(last && bookOf(last.book))) area.appendChild(h('button', { class: 'btn', type: 'button', style: 'margin-top:12px', text: 'Ir ler', onclick: actRead }));
  }

  /* ---------- Home (lote B1): carrossel automático, Palavra do Dia em destaque e Ler a Bíblia ---------- */
  var carAuto = true; /* some pelo resto da sessão depois que a pessoa toca ou desliza */
  function homeResumeBar(l) {
    var w = $('.rbar'), bar = $('#resumeBar'), sub = $('#resumeSub'); if (!w) return;
    if (!l) { w.hidden = true; sub.textContent = ''; return; }
    var b = bookOf(l.book), total = b ? (b.total || b.chapters.length) : 0;
    if (!total) { w.hidden = true; sub.textContent = ''; return; }
    w.hidden = false; bar.style.width = Math.max(4, Math.min(100, Math.round(l.chapter / total * 100))) + '%';
    sub.textContent = 'Capítulo ' + l.chapter + ' de ' + total;
  }
  function slideEl(s) {
    return h('div', { class: 'slide', style: '--img:url(' + s.img + ')' }, [
      h('span', { class: 'eb', text: s.eb }), h('h1', { text: s.t }), s.p ? h('p', { text: s.p }) : null,
      h('button', { class: 'cta', type: 'button', text: s.cta + ' →', onclick: s.go })]);
  }
  async function homeBuild() {
    var imgs = ['assets/hero-bible.jpg', 'assets/hero-dawn.jpg', 'assets/hero-reading.jpg'];
    var hist = (await kvGet('historico')) || {}, pl = await planoGet();
    var ps = manifest.passages || [], dia = Math.floor(Date.now() / 864e5);
    function estudo(k) {
      if (!ps.length) return null;
      var m = ps[(dia * 3 + k) % ps.length]; /* três estudos por dia, em fila: nenhum se repete até passar por todos */
      return { eb: 'Estudo bíblico · ' + m.ref, t: m.titulo || ('Entender ' + m.ref), cta: 'Estudar agora', img: imgs[k % 3], go: function () { go({ v: 'study', id: m.id }); } };
    }
    var nCap = Object.keys(hist.lidos || {}).length, seq = core.diasSeguidos(hist.dias, core.diaStr(Date.now()));
    var jor = nCap
      ? { eb: 'Sua jornada', t: nCap + (nCap === 1 ? ' capítulo lido' : ' capítulos lidos'), p: seq ? seq + (seq === 1 ? ' dia seguido' : ' dias seguidos') + ' de leitura' : 'Continue no seu ritmo', cta: 'Ver minha jornada', img: imgs[2], go: function () { marksTab = 'jornada'; go({ v: 'marks' }); } }
      : { eb: 'Sua jornada', t: 'Comece hoje, um capítulo de cada vez', p: 'O que você ler fica registrado aqui', cta: 'Ler agora', img: imgs[2], go: actRead };
    var lp = planoLista(), d = pl ? planoDia(lp, pl) : null, tot = Math.ceil(lp.length / PLANO.porDia);
    var pla = { eb: 'Plano de leitura', t: PLANO.nome, p: !pl ? 'Três capítulos por dia, no seu ritmo' : d.fim ? 'Plano concluído. Parabéns!' : 'Dia ' + d.dia + ' de ' + tot, cta: !pl ? 'Começar' : d.fim ? 'Ver plano' : 'Continuar plano', img: imgs[1], go: function () { go({ v: 'plano' }); } };
    var lista = [estudo(0), jor, pla, estudo(1), estudo(2)].filter(Boolean);
    var sl = clear($('#slides')), dots = clear($('#hdots'));
    lista.forEach(function (s, i) { sl.appendChild(slideEl(s)); dots.appendChild(h('i', { class: i ? '' : 'on' })); });
    sl.scrollLeft = 0;
    /* Palavra do Dia: sempre visível, com foto, versículo e um só botão */
    var P = window.PVPalavraDia, card = $('#pdCard');
    if (!P || !P.doDia) { card.hidden = true; return; }
    var e = P.doDia();
    $('#pdPh').style.backgroundImage = 'url(' + ['assets/hero-dawn.jpg', 'assets/hero-reading.jpg', 'assets/hero-bible.jpg', 'assets/abencoe.jpg'][P.indiceDoDia(new Date(), P.dados.length) % 4] + ')';
    $('#pdTxt').textContent = '“' + e.texto + '”'; $('#pdRef').textContent = e.ref; card.hidden = false;
    $('#pdOpen').onclick = function () { P.abrirIdx(P.dados.indexOf(e)); };
    $('#pdShare').onclick = function () {
      var txt = P.textoParaCompartilhar(e, baseUrl());
      if (navigator.share) navigator.share({ title: 'Palavra do Dia', text: txt }).catch(function () { /* cancelado */ }); else copy(txt, 'Mensagem copiada');
    };
  }
  function homeInit() {
    var sl = $('#slides'), dots = $('#hdots');
    function cur() { return sl.clientWidth ? Math.round(sl.scrollLeft / sl.clientWidth) : 0; }
    sl.addEventListener('scroll', function () { var i = cur(); [].forEach.call(dots.children, function (d, k) { d.classList.toggle('on', k === i); }); });
    function parar() { carAuto = false; }
    ['pointerdown', 'touchstart', 'wheel', 'keydown'].forEach(function (ev) { sl.addEventListener(ev, parar, { passive: true }); });
    if (window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches) carAuto = false;
    setInterval(function () {
      var n = sl.children.length;
      if (!carAuto || document.hidden || curState.v !== 'home' || overlay || splashOn || n < 2 || !sl.clientWidth) return;
      sl.scrollTo({ left: ((cur() + 1) % n) * sl.clientWidth, behavior: 'smooth' });
    }, 6000);
    $('#bigRead').addEventListener('click', function () { go({ v: 'bible' }); });
  }

  /* ---------- configurações ---------- */
  var dlState = '';
  async function refreshMenuInfo() {
    try {
      var c = await caches.open(CONTENT), have = (await c.keys()).map(function (r) { return relPath(r.url); });
      var base = { packages: manifest.packages.filter(function (p) { return !p.version; }) };
      var need = core.missingPackages(base, have).length, total = base.packages.length;
      dlState = need === 0 ? 'Tudo baixado' : Math.floor((total - need) / total * 100) + '% baixado';
      $('#dlSmall').textContent = dlState;
    } catch (e) { $('#dlSmall').textContent = ''; }
    var est = '';
    try { if (navigator.storage && navigator.storage.estimate) { var e = await navigator.storage.estimate(); est = 'Armazenamento usado: ' + Math.round((e.usage || 0) / 1024 / 1024 * 10) / 10 + ' MB de ' + Math.round((e.quota || 0) / 1024 / 1024) + ' MB.'; } } catch (x) { est = ''; }
    var bt = ''; try { bt = localStorage.getItem('pv_boot') || ''; } catch (x) { bt = ''; }
    if (bt) est += (est ? ' · ' : '') + 'Última abertura até a tela inicial: ' + (Math.round(+bt / 100) / 10) + ' s.';
    $('#storeInfo').textContent = est;
    var pst = '';
    try { if (navigator.storage && navigator.storage.persisted) pst = (await navigator.storage.persisted()) ? 'Protegido' : 'Não protegido'; } catch (x) { pst = ''; }
    $('#persistSmall').textContent = pst;
  }
  function viewMenu() { showScreen('menu'); refreshInstall(); refreshMenuInfo(); refreshVerSmall(); }

  /* ---------- instalar e compartilhar ---------- */
  var deferred = null;
  function isStandalone() { return matchMedia('(display-mode: standalone)').matches || navigator.standalone === true; }
  function refreshInstall() { var b = $('#inst'); if (!b) return; b.textContent = isStandalone() ? '✓ Instalado' : 'Instalar app'; $('#instHint').hidden = isStandalone(); }
  window.addEventListener('beforeinstallprompt', function (e) { e.preventDefault(); deferred = e; refreshInstall(); });
  window.addEventListener('appinstalled', function () { deferred = null; toast('App instalado'); refreshInstall(); });
  function isIOS() { var u = navigator.userAgent || ''; return /iPhone|iPad|iPod/.test(u) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1); }
  function installHelp() {
    if (isIOS()) { /* o iOS não tem botão de instalar para sites: a instalação é feita pelo menu Compartilhar do Safari */
      var outro = /CriOS|FxiOS|EdgiOS|OPiOS|GSA.|FBAN|FBAV|Instagram/.test(navigator.userAgent || '');
      var nodes = [mtag('Instalar', true), h('h2', { text: 'Instalar no iPhone' }),
        h('p', { text: 'No iPhone, o Palavra Viva é instalado pelo próprio Safari. Siga estes passos:' }),
        h('ol', { style: 'padding-left:20px;margin:0 0 10px;line-height:1.6' }, [
          h('li', {}, ['Toque no botão ', h('b', { text: 'Compartilhar' }), ' (o quadrado com uma seta para cima), na barra do Safari.']),
          h('li', {}, ['Role a lista e toque em ', h('b', { text: 'Adicionar à Tela de Início' }), '. Se não aparecer, toque em ', h('b', { text: 'Ver mais' }), ' ou ', h('b', { text: 'Editar ações' }), '.']),
          h('li', {}, ['Toque em ', h('b', { text: 'Adicionar' }), ', no canto superior direito.'])]),
        h('p', { text: 'Pronto: o ícone do Palavra Viva aparece na tela de início e o app abre em tela cheia, funcionando sem internet.' })];
      if (outro) nodes.push(h('p', { class: 'note', text: 'Você está em outro navegador. Se o botão Compartilhar não oferecer “Adicionar à Tela de Início”, abra este endereço no Safari e repita os passos.' }));
      modal(nodes);
      return;
    }
    modal([mtag('Instalar', true), h('h2', { text: 'Instalar aplicativo' }),
      h('p', {}, ['No Android, abra o menu do Chrome (três pontos) e escolha ', h('b', { text: 'Instalar aplicativo' }), ' ou ', h('b', { text: 'Adicionar à tela inicial' }), '. Depois disso o Palavra Viva abre como um aplicativo e funciona sem internet.'])]);
  }
  function install() {
    if (isStandalone()) { toast('O app já está instalado.'); return; }
    if (deferred) { var d = deferred; deferred = null; d.prompt(); d.userChoice.then(refreshInstall, refreshInstall); } else installHelp();
  }
  /* ---------- lembrete diário da Palavra do Dia ---------- */
  function lemInfo(t) { $('#lemInfo').textContent = t; }
  function lemEstado() { return { on: lsGet('pv4-lem', '') === '1', hora: lsGet('pv4-lem-hora', '07:00') }; }
  function lemPush(p) {
    return navigator.serviceWorker.ready.then(function (reg) {
      var c = reg.active; if (!c) return;
      var n = new Date(), hm = p.hora.split(':'), hoje = n.getFullYear() + '-' + (n.getMonth() + 1) + '-' + n.getDate(), passou = n.getHours() * 60 + n.getMinutes() >= (+hm[0] || 0) * 60 + (+hm[1] || 0);
      return caches.open('pvlembrete').then(function (ch) { return ch.put('lembrete', new Response(JSON.stringify({ on: p.on, hora: p.hora, ultimo: p.on && passou ? hoje : '' }), { headers: { 'content-type': 'application/json' } })); })
        .then(function () { return reg.periodicSync ? (p.on ? reg.periodicSync.register('pv-pdia', { minInterval: 12 * 3600 * 1000 }) : reg.periodicSync.unregister('pv-pdia')) : null; });
    });
  }
  var lemTimer = 0;
  function lemAgendar() { /* com o app aberto, avisa na hora marcada */
    clearTimeout(lemTimer); var p = lemEstado(); if (!p.on || !('Notification' in window) || Notification.permission !== 'granted') return;
    var hm = p.hora.split(':'), t = new Date(); t.setHours(+hm[0] || 0, +hm[1] || 0, 0, 0); var ms = t - new Date();
    if (ms > 0 && ms < 2147000000) lemTimer = setTimeout(function () { if (navigator.serviceWorker.controller) navigator.serviceWorker.controller.postMessage({ type: 'LEMBRETE_CHECAR' }); }, ms + 500);
  }
  function lemPintar() {
    var p = lemEstado(), sw = $('#lemSw'), ok = 'serviceWorker' in navigator && 'Notification' in window && !isIOS();
    sw.setAttribute('aria-checked', String(p.on && ok)); $('#lemHora').value = p.hora;
    if (isIOS()) { sw.disabled = true; $('#lemHora').disabled = true; lemInfo('No iPhone, a Apple só permite avisos por meio de um servidor, que este app não usa. Por isso o lembrete não está disponível aqui.'); return; }
    if (!ok) { sw.disabled = true; $('#lemHora').disabled = true; lemInfo('Este navegador não permite lembretes.'); return; }
    if (Notification.permission === 'denied') { lemInfo('As notificações deste app estão bloqueadas nas configurações do aparelho. Libere-as nas configurações do Android para usar o lembrete.'); return; }
    lemInfo(p.on ? 'Ativo. O Android escolhe o instante exato e pode atrasar o aviso. Funciona com o app instalado.' : 'Um convite diário, com um trecho do versículo. Sem som e sem coleta de dados.');
  }
  function lemLigar() {
    modal([mtag('Lembrete diário', true), h('h2', { text: 'Receber a Palavra do Dia' }),
      h('p', { text: 'Para avisar você, o Android precisa da sua permissão para mostrar notificações. Você receberá no máximo uma por dia, com um trecho do versículo e a referência. Pode desligar quando quiser.' }),
      h('button', { class: 'big', type: 'button', text: 'Permitir lembrete', onclick: function () {
        Notification.requestPermission().then(function (r) {
          closeOverlay();
          if (r !== 'granted') { toast('Sem permissão, o lembrete não pode ser ativado.'); lemPintar(); return; }
          lsSet('pv4-lem', '1'); var p = lemEstado();
          lemPush(p).then(function () { toast('Lembrete ativado'); }, function () { toast('Instale o app na tela inicial para receber o lembrete.'); lsSet('pv4-lem', ''); lemPush({ on: false, hora: p.hora }).catch(function () { /* ok */ }); lemPintar(); });
          lemAgendar(); lemPintar();
        });
      } })]);
  }
  function lemBind() {
    $('#lemSw').addEventListener('click', function () {
      if (lemEstado().on) { lsSet('pv4-lem', ''); lemPush({ on: false, hora: lemEstado().hora }).catch(function () { /* ok */ }); clearTimeout(lemTimer); lemPintar(); toast('Lembrete desligado'); return; }
      if (Notification.permission === 'granted') { lsSet('pv4-lem', '1'); var p = lemEstado(); lemPush(p).then(function () { toast('Lembrete ativado'); }, function () { toast('Instale o app na tela inicial para receber o lembrete.'); lsSet('pv4-lem', ''); lemPintar(); }); lemAgendar(); lemPintar(); }
      else if (Notification.permission === 'default') lemLigar();
      else lemPintar();
    });
    $('#lemHora').addEventListener('change', function () { var v = $('#lemHora').value; if (!/^[0-9][0-9]:[0-9][0-9]$/.test(v)) return; lsSet('pv4-lem-hora', v); if (lemEstado().on) { lemPush(lemEstado()).catch(function () { /* ok */ }); lemAgendar(); toast('Horário atualizado'); } });
    if ('serviceWorker' in navigator) navigator.serviceWorker.addEventListener('message', function (e) { if (e.data && e.data.type === 'ABRIR_PDIA' && window.PVPalavraDia) window.PVPalavraDia.abrirIdx(e.data.idx); });
    lemPintar(); lemAgendar();
  }
  /* ---------- "Som ao abrir o app": toca uma vez por abertura (não volta ao retornar do segundo plano). É independente do Clima de Leitura. ---------- */
  function aberturaLigada() { return lsGet('pv4-abertura', '1') !== '0'; }
  function aberturaTocar() {
    if (!aberturaLigada() || ssGet('pv4-abertura-ok') || window.PV_RECENTE) return;
    ssSet('pv4-abertura-ok', '1');
    var s = document.createElement('script'); s.src = 'assets/abertura-som.js';
    s.onload = function () {
      if (!window.PV_ABERTURA) return;
      var a = new Audio(window.PV_ABERTURA), feito = false; a.volume = 0.25;
      function toca() { if (feito) return; feito = true; var p = a.play(); if (p && p.catch) p.catch(function () { /* sem permissão do sistema: fica em silêncio */ }); }
      var p0 = a.play();
      if (p0 && p0.then) p0.then(function () { feito = true; }, function () { /* o navegador pede um toque antes de tocar: aproveita o primeiro toque, só nos primeiros segundos */
        var f = function () { document.removeEventListener('pointerdown', f, true); toca(); };
        document.addEventListener('pointerdown', f, true); setTimeout(function () { document.removeEventListener('pointerdown', f, true); }, 12000);
      });
    };
    document.head.appendChild(s);
  }
  function aberturaBind() {
    var sw = $('#abSw'); sw.setAttribute('aria-checked', String(aberturaLigada()));
    sw.addEventListener('click', function () { var on = !aberturaLigada(); lsSet('pv4-abertura', on ? '1' : '0'); sw.setAttribute('aria-checked', String(on)); toast(on ? 'Som ao abrir o app ligado' : 'Som ao abrir o app desligado'); });
  }
  var APP_NAME = 'Palavra Viva – Aprendendo as Escrituras';
  function baseUrl() { return cfg.siteUrl || (location.origin + location.pathname); }
  function send(data, okMsg) {
    if (navigator.share) navigator.share(data).catch(function () { /* cancelado */ });
    else copy((data.text ? data.text + ' ' : '') + data.url, okMsg || 'Link copiado');
  }
  function share() { send({ title: APP_NAME, text: 'Bíblia em português, grátis e sem internet.', url: baseUrl() }); }
  /* link direto para um estudo: abre o app já naquele estudo */
  function studyUrl(id) { return baseUrl().replace(/#.*$/, '') + '#e=' + encodeURIComponent(id); }
  function metaOf(id) { return (manifest.passages || []).filter(function (p) { return p.id === id; })[0] || null; }
  function shareStudy(id) {
    var m = metaOf(id); if (!m) return share();
    send({ title: m.ref, text: 'Estudo bíblico: ' + m.ref + (m.titulo ? ' – ' + m.titulo : '') + '. Leia no ' + APP_NAME + ':', url: studyUrl(id) });
  }
  /* cartão bíblico: imagem 1080x1350 com a frase para guardar, a referência e o endereço */
  function wrapLines(ctx, text, max) {
    var words = String(text).split(/\s+/), lines = [], cur = '';
    words.forEach(function (w) { var t = cur ? cur + ' ' + w : w; if (ctx.measureText(t).width > max && cur) { lines.push(cur); cur = w; } else cur = t; });
    if (cur) lines.push(cur); return lines;
  }
  function makeCard(frase, ref) {
    return new Promise(function (resolve, reject) {
      try {
        var c = document.createElement('canvas'); c.width = 1080; c.height = 1350; var x = c.getContext('2d');
        var g = x.createLinearGradient(0, 0, 0, 1350); g.addColorStop(0, '#1F2A44'); g.addColorStop(1, '#0F1626'); x.fillStyle = g; x.fillRect(0, 0, 1080, 1350);
        x.fillStyle = '#D9B45B'; x.fillRect(90, 150, 120, 6);
        x.textBaseline = 'alphabetic'; x.fillStyle = '#FCF8EE';
        var size = 64, lines;
        for (; size >= 40; size -= 4) { x.font = '700 ' + size + 'px Georgia, serif'; lines = wrapLines(x, '“' + frase + '”', 900); if (lines.length * size * 1.35 <= 760) break; }
        var y = 300; lines.forEach(function (l) { x.fillText(l, 90, y); y += size * 1.35; });
        x.fillStyle = '#D9B45B'; x.font = '700 40px Georgia, serif'; x.fillText(ref, 90, Math.max(y + 60, 1000));
        x.fillStyle = '#B9C0D0'; x.font = '600 34px sans-serif'; x.fillText(APP_NAME, 90, 1210);
        x.font = '30px sans-serif'; x.fillText(baseUrl().replace(/^https?:\/\//, '').replace(/\/$/, ''), 90, 1260);
        c.toBlob(function (b) { b ? resolve(b) : reject(new Error('sem imagem')); }, 'image/png');
      } catch (e) { reject(e); }
    });
  }
  function shareCard(id, frase) {
    var m = metaOf(id), ref = m ? m.ref : '', url = id ? studyUrl(id) : baseUrl();
    var texto = '“' + frase + '” (' + ref + ')';
    makeCard(frase, ref).then(function (blob) {
      var f = new File([blob], 'cartao-biblico.png', { type: 'image/png' });
      if (navigator.canShare && navigator.canShare({ files: [f] })) navigator.share({ files: [f], title: ref, text: texto + ' ' + url }).catch(function () { /* cancelado */ });
      else send({ title: ref, text: texto, url: url }, 'Texto copiado');
    }, function () { send({ title: ref, text: texto, url: url }, 'Texto copiado'); });
  }

  /* ---------- baixar tudo ---------- */
  async function downloadAll(cb, only) {
    var c = await caches.open(CONTENT);
    var have = (await c.keys()).map(function (r) { return relPath(r.url); });
    /* sem filtro: o essencial (sem traduções extras, que se baixam uma a uma no seletor); com filtro: só aqueles pacotes */
    var scope = { packages: manifest.packages.filter(only || function (p) { return !p.version; }) };
    var need = core.missingPackages(scope, have), total = scope.packages.length, done = total - need.length, fails = 0, i = 0;
    cb(done, total);
    async function worker() {
      while (i < need.length) {
        var e = need[i++];
        try {
          var r = await fetch(e.path, { cache: 'no-store' }); if (!r.ok) throw new Error('http');
          var bytes = new Uint8Array(await r.clone().arrayBuffer());
          if (!(await core.verifyPackage(bytes, e)).ok) throw new Error('hash');
          await c.put(e.path, r); done++;
        } catch (x) { fails++; }
        cb(done, total);
      }
    }
    await Promise.all([worker(), worker(), worker(), worker()]);
    if (!only) for (var m = 0; m < (cfg.audio || []).length; m++) { try { await mediaResponse(cfg.audio[m]); } catch (x) { /* áudio é opcional */ } }
    if (!fails && !only) { kvSet('baixado', { generation: manifest.generation, at: Date.now() }); try { if (navigator.storage && navigator.storage.persist) navigator.storage.persist(); } catch (x) { /* ignora */ } }
    return { done: done, total: total, fails: fails };
  }
  function downloadModal() {
    var bar = h('i', { id: 'pbar' }), txt = h('p', { class: 'dlstat', id: 'ptxt', text: 'Calculando…' });
    var go1 = h('button', { class: 'big', type: 'button', id: 'pgo', text: 'Baixar agora' });
    modal([mtag('Leitura sem internet', true), h('h2', { text: 'Baixar tudo' }), h('p', { style: 'text-align:center', text: 'O texto bíblico e o ensino ficam guardados no aparelho. Você poderá ler no modo avião.' }), h('div', { class: 'prog' }, [bar]), txt, go1]);
    var show = function (d, t) { bar.style.width = (t ? d / t * 100 : 0) + '%'; txt.textContent = d + ' de ' + t + ' partes guardadas'; };
    caches.open(CONTENT).then(function (c) { return c.keys(); }).then(function (ks) {
      var base = { packages: manifest.packages.filter(function (p) { return !p.version; }) };
      var have = ks.map(function (r) { return relPath(r.url); }), t = base.packages.length, n = t - core.missingPackages(base, have).length;
      show(n, t); if (n === t) { go1.textContent = 'Tudo já está no aparelho'; go1.disabled = true; go1.style.opacity = '.7'; }
    });
    go1.onclick = function () {
      go1.disabled = true; go1.style.opacity = '.6'; go1.textContent = 'Baixando…';
      downloadAll(show).then(function (r) {
        go1.style.opacity = '1';
        if (r.fails) { go1.disabled = false; go1.textContent = 'Faltaram ' + r.fails + '. Tentar de novo'; }
        else { go1.textContent = 'Pronto: já funciona sem internet'; }
        refreshMenuInfo();
      }, function () { go1.disabled = false; go1.style.opacity = '1'; go1.textContent = 'Não deu certo. Tentar de novo'; });
    };
  }

  /* ---------- sobre, contato, abençoe ---------- */
  function row(dt, dd) { return h('div', {}, [h('dt', { text: dt }), h('dd', { text: dd })]); }
  function aboutModal() {
    var lic = manifest.license || {}, owner = cfg.ownerName || 'o responsável pelo projeto', yr = cfg.year || String(new Date().getFullYear());
    var dl = h('dl', {}, [
      row('Projeto', 'Palavra Viva – Aprendendo as Escrituras. Gratuito, sem anúncios e sem coleta de dados.'),
      cfg.ownerName ? row('Responsável', cfg.ownerName) : null,
      row('Texto bíblico', versionsList().length > 1 ? 'Traduções disponíveis: ' + versionsList().map(function (v) { return v.sigla; }).join(', ') + '. O crédito e a licença de cada uma estão abaixo e na tela de leitura.' : (lic.text || '')),
      row('Versão', 'App ' + APP_VERSION + ' · conteúdo ' + manifest.contentVersion + ' (geração ' + manifest.generation + ')')
    ]);
    var nodes = [mtag(APP_NAME, true), h('h2', { text: 'Sobre' }), dl];
    /* créditos e licenças das traduções ficam dentro de um bloco que abre ao toque (o texto completo continua aqui e na tela de Créditos) */
    var det = h('details', { style: 'margin:12px 0 0;padding:0 12px;border-radius:14px;background:var(--paper)' }, [h('summary', { style: 'min-height:44px;display:flex;align-items:center;font-weight:700;font-size:14px;cursor:pointer', text: 'Traduções e licenças' })]);
    versionsList().forEach(function (v) {
      det.appendChild(h('p', { style: 'font-size:13px;line-height:1.5;margin:10px 0 4px' }, [h('b', { text: v.sigla + ' · ' + covLabel(v) }), h('br'), v.credito || '']));
      if (v.licencaUrl) det.appendChild(h('p', { style: 'margin:0 0 10px' }, [h('a', { href: v.licencaUrl, rel: 'noopener', target: '_blank', text: 'Licença de ' + v.sigla + ' (' + (v.licenca || '') + ')' })]));
    });
    nodes.push(det);
    var USERS = '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>';
    var ic = h('span', { 'aria-hidden': 'true', style: 'flex:none;display:flex;align-items:center;justify-content:center;width:34px;height:34px;border-radius:50%;overflow:hidden;color:var(--accent);background:var(--gold-soft)' }); ic.innerHTML = USERS; /* SVG fixo do próprio app */
    var fo = new Image(); fo.alt = ''; fo.style.cssText = 'width:100%;height:100%;object-fit:cover;display:none'; /* miniatura do responsável, se a foto existir */
    fo.onload = function () { ic.innerHTML = ''; fo.style.display = 'block'; ic.appendChild(fo); };
    if (window.PV_FOTO) fo.src = window.PV_FOTO; else { var sc = document.createElement('script'); sc.src = 'assets/foto-responsavel.js'; sc.onload = function () { if (window.PV_FOTO) fo.src = window.PV_FOTO; }; document.head.appendChild(sc); }
    nodes.push(h('a', { href: 'assets/creditos.html', target: '_blank', rel: 'noopener', style: 'display:flex;align-items:center;gap:10px;margin:10px 0 0;padding:8px 10px;border-radius:14px;background:var(--paper);color:inherit;font-weight:400;text-decoration:none;word-break:normal' }, [
      ic,
      h('span', { style: 'flex:1;min-width:0' }, [h('strong', { style: 'display:block;font-size:13px;color:var(--accent)', text: 'Créditos e colaboradores' }), h('span', { style: 'display:block;font-size:11px;line-height:1.3;color:var(--soft)', text: 'Pessoas, inteligências artificiais e ferramentas do projeto.' })]),
      h('span', { 'aria-hidden': 'true', style: 'flex:none;font-size:18px;color:var(--soft)', text: '›' })
    ]));
    nodes.push(h('p', { style: 'font-size:10.5px;line-height:1.45;color:var(--soft);text-align:center;margin:14px 0 0;opacity:.9' }, [
      '© ' + yr + ' ' + owner + '. Aplicativo, código e organização dos estudos: todos os direitos reservados. Textos bíblicos: cada tradução segue a licença indicada nos créditos dela (' + versionsList().map(function (v) { return v.sigla + ', ' + v.licenca; }).join('; ') + '). Os estudos são elaborados com apoio de inteligência artificial e não substituem a Bíblia. ',
      h('a', { href: 'assets/termos.html', target: '_blank', rel: 'noopener', style: 'font-size:10.5px;font-weight:600;word-break:normal;text-decoration:underline', text: 'Termos de Uso e Privacidade' })
    ]));
    modal(nodes);
  }
  function contactModal() {
    var mail = cfg.contactEmail;
    modal([mtag('Fale conosco', true), h('h2', { text: 'Contato e suporte' }), h('p', { style: 'text-align:center', text: 'Para dúvidas, sugestões ou suporte, escreva para:' }),
      h('p', { style: 'text-align:center' }, [h('a', { href: 'mailto:' + mail, text: mail })]),
      h('button', { class: 'big', type: 'button', text: 'Copiar e-mail', onclick: function () { copy(mail, 'E-mail copiado'); } })]);
  }
  function blessModal() {
    var img = h('div', { class: 'mimg' }), probe = new Image();
    probe.onload = function () { img.style.setProperty('--img', 'url(assets/abencoe.jpg)'); };
    probe.onerror = function () { img.style.setProperty('--img', 'url(assets/hero-reading.jpg)'); };
    probe.src = 'assets/abencoe.jpg';
    modal([img, mtag('Um gesto de continuidade'), h('h2', { text: 'Abençoe este Projeto' }),
      h('p', { text: 'O aplicativo Palavra Viva nasceu para tornar a Palavra mais próxima, simples e presente na vida de cada pessoa.' }),
      h('p', { text: 'Se este projeto tem edificado sua caminhada, você pode contribuir voluntariamente para ele continuar crescendo e alcançando outras vidas.' }),
      h('span', { class: 'note', text: 'Cada apoio é recebido com gratidão.' }),
      mtag('Contribuição voluntária via Pix'),
      h('button', { class: 'big', type: 'button', text: 'Copiar chave Pix', onclick: function () { copy(cfg.pixKey, 'Chave Pix copiada'); } }),
      h('p', { style: 'text-align:center;font-size:12px;color:var(--soft);margin-top:8px', text: 'A chave não aparece na tela: ela é copiada para você colar no aplicativo do seu banco.' })]);
  }

  /* ---------- Clima de Leitura: música instrumental baixinho para refletir enquanto se lê ----------
     Toca o arquivo do projeto (trilhas em config.json); sem ele, um pad suave sintetizado. Os controles ficam em src/audio-ui.js, que usa window.PVClima.
     Mixagem: enquanto a Narração toca, o Clima baixa sozinho para 15% (nunca sobe acima do que a pessoa escolheu) e volta ao normal quando ela pausa ou termina. */
  var CLIMA_VOL_PADRAO = 20, CLIMA_VOL_NARRANDO = 14; /* em % */
  var aud = { on: false, tocando: false, esperando: false, armado: null, el: null, url: null, ctx: null, master: null, oscs: [], duck: false, fade: 0 };
  function climaVolUsuario() { var v = parseInt(lsGet('pv4-vol', String(CLIMA_VOL_PADRAO)), 10); return v >= 0 && v <= 100 ? v : CLIMA_VOL_PADRAO; }
  function volume() { var u = climaVolUsuario(); if (aud.duck) u = Math.min(u, CLIMA_VOL_NARRANDO); return u / 100; } /* volume de saída agora, de 0 a 1 */
  function climaAviso() { try { document.dispatchEvent(new CustomEvent('pv-clima')); } catch (x) { /* ok */ } }
  /* aplica o volume de saída; suave = descida/subida gradual (0,6 s) para a mixagem não dar um tranco */
  function climaAplicar(suave, ms) { ms = ms || 600;
    var alvo = volume();
    if (aud.master && aud.ctx) {
      var g = aud.master.gain, t = aud.ctx.currentTime;
      try { g.cancelScheduledValues(t); g.setValueAtTime(g.value, t); g.linearRampToValueAtTime(alvo * 0.8, t + (suave ? ms / 1000 : 0.1)); } catch (x) { g.value = alvo * 0.8; }
    }
    clearInterval(aud.fade);
    if (aud.el) {
      if (!suave) { aud.el.volume = alvo; return; }
      var de = aud.el.volume, n = 0, passos = Math.max(1, Math.round(ms / 50));
      aud.fade = setInterval(function () {
        n++; if (!aud.el) { clearInterval(aud.fade); return; }
        aud.el.volume = Math.max(0, Math.min(1, de + (alvo - de) * n / passos));
        if (n >= passos) clearInterval(aud.fade);
      }, 50);
    }
  }
  var duckT = 0;
  function climaAbafar(on) {
    clearTimeout(duckT);
    if (on) { if (!aud.duck) { aud.duck = true; climaAplicar(true, 800); climaAviso(); } return; } /* narração começa/retoma: desce em 0,8 s */
    /* pequena espera: na troca automática de capítulo a Narração para e recomeça logo em seguida, e o Clima não precisa subir e descer */
    duckT = setTimeout(function () { if (aud.duck) { aud.duck = false; climaAplicar(true, 1000); climaAviso(); } }, 500); /* pausa/fim: sobe em 1 s */
  }
  async function mediaResponse(src) {
    var c = await caches.open(MEDIA), r = await c.match(src);
    if (!r) { r = await fetch(src); if (!r.ok) throw new Error('sem arquivo'); await c.put(src, r.clone()); }
    return r;
  }
  function startSynth() {
    var C = window.AudioContext || window.webkitAudioContext; if (!C) return false;
    aud.ctx = aud.ctx || new C(); if (aud.ctx.state === 'suspended') aud.ctx.resume();
    var ac = aud.ctx; aud.master = ac.createGain(); aud.master.gain.value = 0;
    var lp = ac.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 900; aud.master.connect(lp); lp.connect(ac.destination);
    [130.81, 196, 261.63, 329.63].forEach(function (f, i) {
      var o = ac.createOscillator(); o.type = 'sine'; o.frequency.value = f;
      var g = ac.createGain(); g.gain.value = 0.12 / (1 + i * 0.4);
      var l = ac.createOscillator(); l.frequency.value = 0.07 + i * 0.03; var lg = ac.createGain(); lg.gain.value = 0.05; l.connect(lg); lg.connect(g.gain);
      o.connect(g); g.connect(aud.master); o.start(); l.start(); aud.oscs.push(o, l);
    });
    aud.master.gain.linearRampToValueAtTime(volume() * 0.8, ac.currentTime + 2.5);
    return true;
  }
  /* semGesto: tentativa ao abrir o app, sem toque da pessoa. Se o navegador bloquear, devolve 'bloqueado' (e não cai no pad mudo) para tentar de novo no primeiro toque. */
  async function startAudio(semGesto) {
    var lista = cfg.audio || [], i = parseInt(lsGet('pv4-trilha', '0'), 10) || 0;
    var tent = [lista[i], lista[0]].filter(function (x, k, a) { return x && a.indexOf(x) === k; });
    for (var k = 0; k < tent.length; k++) {
      try {
        var blob = await (await mediaResponse(tent[k])).blob();
        aud.url = URL.createObjectURL(blob); aud.el = new Audio(aud.url); aud.el.loop = true; aud.el.volume = volume();
        await aud.el.play(); return true;
      } catch (e) {
        if (aud.el) { aud.el.pause(); aud.el = null; } if (aud.url) { URL.revokeObjectURL(aud.url); aud.url = null; }
        if (semGesto && e && e.name === 'NotAllowedError') return 'bloqueado';
      }
    }
    var sint = startSynth();
    if (sint && semGesto && aud.ctx && aud.ctx.state === 'suspended') { stopAudio(); return 'bloqueado'; } /* sem toque, o navegador deixa o pad mudo */
    return sint;
  }
  function stopAudio() {
    clearInterval(aud.fade);
    if (aud.el) { aud.el.pause(); aud.el = null; }
    if (aud.url) { URL.revokeObjectURL(aud.url); aud.url = null; }
    if (aud.master && aud.ctx) {
      aud.master.gain.linearRampToValueAtTime(0, aud.ctx.currentTime + 1);
      var o = aud.oscs, m = aud.master; aud.oscs = []; aud.master = null;
      setTimeout(function () { o.forEach(function (x) { try { x.stop(); } catch (e) { /* já parou */ } }); try { m.disconnect(); } catch (e) { /* ok */ } }, 1200);
    }
    aud.tocando = false;
  }
  function climaDesarmar() {
    if (aud.armado) { ['pointerdown', 'keydown', 'touchend'].forEach(function (ev) { document.removeEventListener(ev, aud.armado, true); }); aud.armado = null; }
    aud.esperando = false;
  }
  /* liga/desliga (com memória: a escolha vale na próxima abertura). Devolve true se ficou como pedido. */
  async function climaLigar(want) {
    climaDesarmar();
    if (want) {
      if (aud.on && aud.tocando) return true;
      aud.on = true; climaAviso();
      var ok = await startAudio();
      if (!aud.on) { if (ok === true) stopAudio(); return false; } /* a pessoa desligou enquanto carregava */
      if (!ok) { aud.on = false; aud.tocando = false; lsSet('pv4-clima-on', '0'); climaAviso(); toast('O Clima de Leitura não conseguiu tocar neste celular.'); return false; }
      aud.tocando = true; lsSet('pv4-clima-on', '1'); climaAviso(); return true;
    }
    aud.on = false; stopAudio(); lsSet('pv4-clima-on', '0'); climaAviso(); return true;
  }
  /* ao abrir o app: se estava ligado na última vez, liga de novo. O navegador pode exigir um toque antes de tocar som: nesse caso começa no primeiro toque. */
  function climaRestaurar() {
    if (lsGet('pv4-clima-on', '0') !== '1' || aud.on) return;
    aud.on = true; climaAviso();
    startAudio(true).then(function (r) {
      if (!aud.on) { if (r === true) stopAudio(); return; } /* a pessoa desligou enquanto carregava */
      if (r === true) { aud.tocando = true; climaAviso(); return; }
      if (r !== 'bloqueado') { aud.on = false; climaAviso(); return; }
      aud.esperando = true; climaAviso();
      aud.armado = function () {
        climaDesarmar();
        if (!aud.on || aud.tocando) return;
        startAudio().then(function (ok) {
          if (!aud.on) { if (ok === true) stopAudio(); } /* a pessoa desligou nesse mesmo toque */
          else if (ok === true) aud.tocando = true;
          else aud.on = false;
          climaAviso();
        });
      };
      ['pointerdown', 'keydown', 'touchend'].forEach(function (ev) { document.addEventListener(ev, aud.armado, true); });
    });
  }
  function climaFaixas() { var l = cfg.audio || [], n = cfg.audioNomes || []; return l.map(function (src, i) { return { i: i, nome: n[i] || ('Trilha ' + (i + 1)) }; }); }
  function climaTrilha() { var c = parseInt(lsGet('pv4-trilha', '0'), 10), n = (cfg.audio || []).length; return c >= 0 && c < n ? c : 0; }
  window.PVClima = {
    estado: function () { return { on: aud.on, tocando: aud.tocando, esperando: aud.esperando, abafado: aud.duck, vol: climaVolUsuario(), trilha: climaTrilha(), faixas: climaFaixas() }; },
    ligar: climaLigar,
    volume: function (v) { v = Math.max(0, Math.min(100, Math.round(+v) || 0)); lsSet('pv4-vol', String(v)); climaAplicar(false); climaAviso(); },
    trilha: async function (i) {
      lsSet('pv4-trilha', String(i)); climaAviso();
      if (aud.on && aud.tocando) { stopAudio(); aud.tocando = !!(await startAudio()); if (!aud.tocando) { aud.on = false; lsSet('pv4-clima-on', '0'); toast('O Clima de Leitura não conseguiu tocar neste celular.'); } climaAviso(); }
    },
    abafar: climaAbafar,
    padrao: CLIMA_VOL_PADRAO, narrando: CLIMA_VOL_NARRANDO
  };

  /* ---------- atualização do app (botão "Atualizar", sem skipWaiting automático) ---------- */
  function setupSW() {
    if (!('serviceWorker' in navigator)) return;
    var banner = $('#update');
    navigator.serviceWorker.register('sw.js', { updateViaCache: 'none' }).then(function (reg) {
      function offer(w) { banner.hidden = false; $('#do-update').onclick = function () { w.postMessage({ type: 'SKIP_WAITING' }); }; }
      if (reg.waiting && navigator.serviceWorker.controller) offer(reg.waiting);
      reg.addEventListener('updatefound', function () {
        var w = reg.installing; if (!w) return;
        w.addEventListener('statechange', function () { if (w.state === 'installed' && navigator.serviceWorker.controller) offer(w); });
      });
      reg.update().catch(function () { /* offline */ });
      document.addEventListener('visibilitychange', function () { if (document.visibilityState === 'visible') reg.update().catch(function () { /* offline */ }); });
    }).catch(function () { /* sem service worker: o app continua funcionando online */ });
    var reloaded = false;
    navigator.serviceWorker.addEventListener('controllerchange', function () { if (reloaded) return; reloaded = true; location.reload(); });
  }

  /* ---------- ligações dos elementos fixos ---------- */
  /* ---------- Anotações: texto livre guardado só neste aparelho (IndexedDB, loja "notes"; entra no backup) ---------- */
  function notasLer() { return tx('notes', 'readonly', function (s) { return s.getAll(); }).then(function (l) { return (l || []).filter(function (n) { return n && n.id; }).sort(function (a, b) { return (b.editado || 0) - (a.editado || 0); }); }).catch(function () { return []; }); }
  function notaGravar(n) { return tx('notes', 'readwrite', function (s) { return s.put(n, n.id); }); }
  function notaApagar(id) { return tx('notes', 'readwrite', function (s) { return s.delete(id); }); }
  function notasAbrir(opts) {
    var est = curState && curState.v === 'study' ? metaOf(curState.id) : null, edit = (opts && opts.edit) || null, pre = opts && opts.ref ? { ref: opts.ref, vk: opts.vk } : null;
    var ta = h('textarea', { class: 'ntxt', maxlength: '5000', rows: '5', placeholder: 'Escreva aqui a sua anotação…', 'aria-label': 'Anotação' });
    var lig = h('p', { class: 'nlig' }), lista = h('div', { class: 'nlist' });
    var salvar = h('button', { class: 'big', type: 'button', text: 'Salvar anotação' });
    function liga() { var e = edit ? (edit.estudo ? { id: edit.estudo, ref: edit.ref } : (edit.vk ? { vk: edit.vk, ref: edit.ref } : null)) : (pre || (est ? { id: est.id, ref: est.ref } : null)); lig.textContent = e ? (e.vk ? 'Ligada ao versículo: ' : 'Ligada ao estudo: ') + e.ref : ''; lig.hidden = !e; return e; }
    function zera() { edit = null; pre = null; ta.value = ''; salvar.textContent = 'Salvar anotação'; liga(); }
    function pintar() {
      notasLer().then(function (l) {
        clear(lista);
        if (!l.length) { lista.appendChild(h('p', { class: 'empty', text: 'Você ainda não tem anotações.' })); return; }
        l.forEach(function (n) {
          var d = new Date(n.editado || n.criado || 0).toLocaleDateString('pt-BR');
          lista.appendChild(h('div', { class: 'nitem' }, [
            h('div', { class: 'nmeta', text: d + (n.ref ? ' · ' + n.ref : '') }),
            h('p', { class: 'ntexto', text: n.texto }),
            h('div', { class: 'row' }, [
              n.estudo && metaOf(n.estudo) ? h('button', { class: 'nbtn', type: 'button', text: 'Abrir estudo', onclick: function () { go({ v: 'study', id: n.estudo }); } }) : null,
              n.vk ? h('button', { class: 'nbtn', type: 'button', text: 'Ler versículo', onclick: function () { var q = n.vk.split(':'); go({ v: 'read', b: q[0], c: parseInt(q[1], 10), verse: parseInt(q[2], 10) }); } }) : null,
              h('button', { class: 'nbtn', type: 'button', text: 'Editar', onclick: function () { edit = n; ta.value = n.texto; liga(); salvar.textContent = 'Salvar alterações'; ta.focus(); } }),
              h('button', { class: 'nbtn', type: 'button', text: 'Excluir', onclick: function () { if (window.confirm('Excluir esta anotação?')) notaApagar(n.id).then(function () { if (edit && edit.id === n.id) zera(); pintar(); aposNota(); }); } })])]));
        });
      });
    }
    salvar.addEventListener('click', function () {
      var t = ta.value.trim(); if (!t) { toast('Escreva algo antes de salvar.'); return; }
      var e = liga(), agora = Date.now();
      var n = edit ? { id: edit.id, texto: t, estudo: edit.estudo || null, ref: edit.ref || null, criado: edit.criado || agora, editado: agora }
        : { id: 'n' + agora + Math.random().toString(36).slice(2, 6), texto: t, estudo: e && e.id ? e.id : null, ref: e ? e.ref : null, vk: e && e.vk ? e.vk : null, criado: agora, editado: agora };
      if (edit && edit.vk) n.vk = edit.vk;
      notaGravar(n).then(function () { toast('Anotação salva'); zera(); pintar(); aposNota(); }, function () { toast('Não foi possível salvar neste aparelho.'); });
    });
    modal([mtag('Meu caderno', true), h('h2', { text: 'Anotações' }), lig, ta, salvar, lista]);
    if (edit) { ta.value = edit.texto; salvar.textContent = 'Salvar alterações'; }
    liga(); pintar();
  }
  function bindStatic() {
    var splash = $('#splash'), t0 = Date.now();
    function marcaAbertura() { ssSet('pv4-splash', '1'); lsSet('pv4-splash-t', String(Date.now())); }
    function hideSplash() { if (!splashOn) return; splashOn = false; splash.classList.add('off'); marcaAbertura(); applyAppearance(); }
    /* a abertura fica na tela, em verde-escuro, até o app terminar de carregar (mínimo 0,3 s) */
    appReady = function () { setTimeout(hideSplash, Math.max(0, 300 - (Date.now() - t0))); };
    /* já abriu há pouco (ex.: voltando de Créditos): abre direto, sem mostrar a abertura outra vez (src/boot.js já escondeu antes da primeira pintura) */
    if (ssGet('pv4-splash') || window.PV_RECENTE) { splashOn = false; splash.classList.add('off'); marcaAbertura(); applyAppearance(); }
    else { setTimeout(hideSplash, 3500); splash.addEventListener('click', hideSplash); splash.addEventListener('keydown', function (e) { if (e.key === 'Enter' || e.key === ' ') hideSplash(); }); }
    /* botões do topo e da barra inferior */
    $('#menuBtn').addEventListener('click', openDrawer);
    $('#dClose').addEventListener('click', closeOverlay);
    $('#drawerBg').addEventListener('click', function (e) { if (e.target.id === 'drawerBg') closeOverlay(); });
    $('#mClose').addEventListener('click', closeOverlay);
    $('#modalBg').addEventListener('click', function (e) { if (e.target.id === 'modalBg') closeOverlay(); });
    $$('.nav button').forEach(function (b) { b.addEventListener('click', function () { var t = b.dataset.tab; if (t === 'drawer') openDrawer(); else if (curState.v === t) $('#s-' + t).scrollTo({ top: 0, behavior: 'smooth' }); else go({ v: t }); }); });
    (function () { var ab = $('#aaBtn'), ro = $('#rdOpts'); ab.addEventListener('click', function () { ro.hidden = !ro.hidden; ab.setAttribute('aria-expanded', String(!ro.hidden)); }); })();
    /* busca a um toque em todas as telas de leitura e estudo */
    ['chap', 'read', 'study', 'ens', 'marks', 'bible'].forEach(function (n) {
      var tb = $('#s-' + n + ' .topbar'); if (!tb) return;
      var sb = h('button', { class: 'tsearch', type: 'button', 'aria-label': 'Buscar livro ou palavra', onclick: function () { go({ v: 'search' }); } });
      sb.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg>'; /* SVG fixo do próprio app */
      tb.appendChild(sb);
      if (n === 'study' || n === 'ens') {
        var nb = h('button', { class: 'tnota', type: 'button', 'aria-label': 'Anotações', title: 'Anotações', onclick: notasAbrir });
        nb.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><rect x="5" y="3" width="14" height="18" rx="2"/><path d="M9 3v18M12 8h4M12 12h4"/></svg>'; /* SVG fixo do próprio app */
        tb.insertBefore(nb, sb);
      }
    });
    /* deslizar para os lados na leitura troca de capítulo (ignora as bordas da tela, usadas pelo gesto de voltar do Android) */
    (function () {
      var r = $('#s-read'), x0 = 0, y0 = 0, t0 = 0;
      r.addEventListener('touchstart', function (e) { var t = e.changedTouches[0]; x0 = t.clientX; y0 = t.clientY; t0 = Date.now(); }, { passive: true });
      r.addEventListener('touchend', function (e) {
        var t = e.changedTouches[0], dx = t.clientX - x0, dy = t.clientY - y0;
        if (Date.now() - t0 > 700 || Math.abs(dx) < 90 || Math.abs(dy) > 45 || x0 < 24 || x0 > innerWidth - 24) return;
        if (e.target.closest && e.target.closest('input,select,.rdopts')) return;
        var bt = dx < 0 ? $('#chNext') : $('#chPrev'); if (bt && !bt.hidden) bt.click();
      }, { passive: true });
    })();
    /* tela do plano de leitura, criada aqui para ter o mesmo botão Voltar das demais */
    (function () {
      var sec = document.createElement('section'); sec.className = 'screen'; sec.id = 's-plano'; sec.setAttribute('aria-label', 'Plano de leitura');
      sec.innerHTML = '<div class="topbar"><button class="back" type="button" data-back><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M19 12H5M11 6l-6 6 6 6"/></svg>Voltar</button><h2>Plano de leitura</h2></div><div class="pad" id="planoBody"></div>'; /* HTML fixo do próprio app */
      $('#app').insertBefore(sec, $('#s-menu'));
    })();
    $$('[data-back]').forEach(function (b) { b.addEventListener('click', back); });
    homeInit();
    $$('[data-act]').forEach(function (b) { b.addEventListener('click', function () { var a = b.dataset.act; if (a === 'read') actRead(); else if (a === 'study') actStudy(); else if (a === 'ensinos') go({ v: 'ens' }); else go({ v: 'marks' }); }); });
    $$('.tt button').forEach(function (c) { c.addEventListener('click', function () { testament = c.dataset.t; $$('.tt button').forEach(function (x) { x.setAttribute('aria-pressed', String(x === c)); }); drawBooks(); }); });
    $('#goSearch').addEventListener('click', function () { go({ v: 'search' }); });
    var qt = null; $('#q').addEventListener('input', function (e) { clearTimeout(qt); var v = e.target.value; qt = setTimeout(function () { runSearch(v); }, 250); });
    $('#fsz').addEventListener('click', function (e) { var s = e.target.closest('button'); if (!s) return; lsSet('pv4-fs', s.dataset.s); applyAppearance(); });
    function tamLetra(e) { var v = parseFloat(e.target.value); if (!(v >= 1 && v <= 1.5)) return; lsSet('pv4-fs', String(v)); applyAppearance(); }
    $('#fsRead').addEventListener('input', tamLetra); $('#fsRange').addEventListener('input', tamLetra);
    $('#palPop').addEventListener('click', function (e) { var b = e.target.closest('button'); if (!b) return; lsSet('pv4-cor', b.dataset.c); applyAppearance(); });
    $('#thm').addEventListener('click', function (e) { var s = e.target.closest('button'); if (!s) return; lsSet('pv4-theme', s.dataset.m); applyAppearance(); });
    matchMedia('(prefers-color-scheme: dark)').addEventListener('change', applyAppearance);
    $('#inst').addEventListener('click', install); $('#shr').addEventListener('click', share);
    $('#shHomeStudy').addEventListener('click', function () { var f = featured(); if (f) shareStudy(f.id); else share(); }); $('#shHomeApp').addEventListener('click', share);
    $('#audbtn').addEventListener('click', function () { if (window.PVAudioMenu) window.PVAudioMenu(); }); $('#dlbtn').addEventListener('click', downloadModal); $('#verbtn').addEventListener('click', versionModal);
    $('#expbtn').addEventListener('click', function () {
      exportAll().then(function (o) {
        var a = h('a', { href: URL.createObjectURL(new Blob([JSON.stringify(o)], { type: 'application/json' })), download: 'palavra-viva-backup.json' });
        document.body.appendChild(a); a.click(); a.remove(); toast('Backup gerado');
      }, function () { toast('Não foi possível gerar o backup.'); });
    });
    $('#impfile').addEventListener('change', function (e) {
      var f = e.target.files && e.target.files[0]; if (!f) return;
      if (f.size > 20000000) { toast('Arquivo grande demais para ser um backup.'); e.target.value = ''; return; }
      f.text().then(function (t) { return importAll(JSON.parse(t)); }).then(function () { toast('Backup importado'); }, function (er) { toast(er.message || 'Arquivo inválido.'); });
      e.target.value = '';
    });
    $('#persist').addEventListener('click', function () {
      if (navigator.storage && navigator.storage.persist) navigator.storage.persist().then(function (ok) { toast(ok ? 'Dados protegidos' : 'O navegador não concedeu a proteção.'); refreshMenuInfo(); });
      else toast('Este navegador não oferece essa proteção.');
    });
    $$('[data-d]').forEach(function (b) {
      b.addEventListener('click', function () {
        var d = b.dataset.d;
        if (d === 'audio') { if (window.PVAudioMenu) window.PVAudioMenu(); return; }
        if (d === 'cfg') go({ v: 'menu' });
        else if (d === 'dl') downloadModal(); else if (d === 'inst') { if (isStandalone()) { closeOverlay(); toast('O app já está instalado.'); } else if (deferred) { closeOverlay(); install(); } else installHelp(); }
        else if (d === 'shr') { closeOverlay(); share(); } else if (d === 'bless') blessModal(); else if (d === 'contact') contactModal(); else if (d === 'about') aboutModal();
      });
    });
    window.addEventListener('online', function () {
      syncManifest().then(function (m) { if (m && manifest && m.generation !== manifest.generation) { manifest = m; indexManifest(); if (curState.v === 'home') render(curState); } }, function () { /* ok */ });
    });
  }

  function fillRights() {
    var t = cfg.ownerName ? '© ' + (cfg.year || new Date().getFullYear()) + ' ' + cfg.ownerName + ' · Aplicativo e organização dos estudos' : '';
    ['rightsHome', 'rightsMenu'].forEach(function (id) { var e = $('#' + id); if (e) { e.textContent = t; e.hidden = !t; } });
  }

  /* ---------- partida ---------- */
  /* carrossel de estudos: passa sozinho a cada 5 s; pausa ao tocar, em segundo plano, com janela aberta ou com "reduzir movimento" */
  function autoRail() {
    var rail = document.querySelector('#railSec .rail'); if (!rail) return;
    var quiet = 0, still = true;
    ['touchstart', 'pointerdown', 'wheel', 'keydown'].forEach(function (ev) { rail.addEventListener(ev, function () { still = false; quiet = Date.now() + 12000; }, { passive: true }); });
    [300, 1200, 2500].forEach(function (ms) { setTimeout(function () { if (still && curState && curState.v === 'home') rail.scrollLeft = 0; }, ms); }); /* o primeiro cartão (Palavra do Dia) começa visível */
    if (window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches) return;
    setInterval(function () {
      if (document.visibilityState !== 'visible' || splashOn || overlay || !curState || curState.v !== 'home' || Date.now() < quiet) return;
      var cs = [].filter.call(rail.children, function (c) { return !c.hidden && c.offsetWidth; }); if (cs.length < 2) return;
      var x = rail.scrollLeft, k = 0, base = cs[0].offsetLeft;
      cs.forEach(function (c, i) { if (c.offsetLeft - base <= x + 8) k = i; });
      rail.scrollTo({ left: cs[(k + 1) % cs.length].offsetLeft - base, behavior: 'smooth' });
    }, 5000);
  }
  (async function start() {
    aberturaTocar(); applyAppearance(); bindStatic(); refreshInstall(); lemBind(); aberturaBind();
    setupSW();
    /* abre na hora com o que já está guardado no aparelho; a internet só atualiza por trás */
    var stored = null;
    try { var cc = await caches.open(CONTENT), sm = await cc.match('content-manifest.json'); if (sm) stored = await sm.json(); } catch (e) { stored = null; }
    var cfgDone = loadConfig().then(function () { fillRights(); climaAviso(); climaRestaurar(); $('#blessItem').hidden = !cfg.pixKey; });
    function showFirst() {
      indexManifest();
      var s = history.state;
      if (s && s.v && !s.o) curState = s; else { curState = { v: 'home', d: Math.max(0, ((s && s.d) || 1) - 1) }; history.replaceState(curState, ''); }
      render(curState);
      var dl = /[#&]e=([^&]+)/.exec(location.hash || '');
      if (dl && !(s && s.v)) { var did = decodeURIComponent(dl[1]); if (metaOf(did)) go({ v: 'study', id: did }); }
    }
    try {
      if (stored && stored.bible) {
        manifest = stored; showFirst();
        /* a verificação de novidades espera a tela abrir e o aparelho sossegar: não disputa a partida */
        setTimeout(function () { syncManifest().then(function (m) { if (m && manifest && m.generation !== manifest.generation) { manifest = m; indexManifest(); if (curState && curState.v === 'home') render(curState); } }, function () { /* sem internet: segue com o guardado */ }); }, 4000);
      } else {
        await cfgDone;
        manifest = await syncManifest();
        if (!manifest) throw new Error('Sem conexão e sem conteúdo guardado. Abra o app uma vez com internet.');
        showFirst();
      }
    } catch (e) { fail(e); }
    appReady(); autoRail();
    try { localStorage.setItem('pv_boot', String(Math.round(performance.now()))); } catch (x) { /* ok */ }
  })();
})();
